// Hint Extension - Complete Working Version with Friends
// Copy this ENTIRE file and replace your popup.js

let supabaseUrl = '';
let supabaseKey = '';
let currentUser = null;
let currentLists = [];
let currentProducts = [];
let viewingListId = null;

document.addEventListener('DOMContentLoaded', async () => {
  await loadTheme();
  await loadConfig();
  setupEventListeners();
});

async function loadTheme() {
  const { theme } = await chrome.storage.local.get('theme');
  if (theme) {
    document.documentElement.setAttribute('data-theme', theme);
  }
}

async function loadConfig() {
  const config = await chrome.storage.local.get(['supabaseUrl', 'supabaseKey', 'session']);
  
  if (config.supabaseUrl && config.supabaseKey) {
    supabaseUrl = config.supabaseUrl;
    supabaseKey = config.supabaseKey;
    
    if (config.session && config.session.user) {
      currentUser = config.session.user;
      showApp();
      await loadUserData();
      await autoFillCurrentPage();
    } else if (config.session && config.session.access_token) {
      currentUser = config.session;
      showApp();
      await loadUserData();
      await autoFillCurrentPage();
    } else {
      showLogin();
    }
  } else {
    showConfig();
  }
}

function setupEventListeners() {
  document.getElementById('saveConfigBtn').addEventListener('click', saveConfig);
  document.getElementById('showConfigLink').addEventListener('click', (e) => {
    e.preventDefault();
    showConfig();
  });
  
  document.getElementById('loginBtn').addEventListener('click', login);
  document.getElementById('loginPassword').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      login();
    }
  });
  document.getElementById('signupBtn').addEventListener('click', signup);
  document.getElementById('signupPassword').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      signup();
    }
  });
  document.getElementById('showSignupBtn').addEventListener('click', showSignup);
  document.getElementById('showLoginLink').addEventListener('click', (e) => {
    e.preventDefault();
    showLogin();
  });
  document.getElementById('logoutBtn').addEventListener('click', logout);
  
  document.getElementById('addTab').addEventListener('click', () => switchTab('add'));
  document.getElementById('myListsTab').addEventListener('click', () => switchTab('myLists'));
  document.getElementById('myClaimsTab').addEventListener('click', () => switchTab('myClaims'));
  document.getElementById('viewHintlistTab').addEventListener('click', () => switchTab('viewHintlist'));
  
  // Header Friends buttons
  const browseFriendsBtn = document.getElementById('browseFriendsBtn');
  if (browseFriendsBtn) {
    browseFriendsBtn.addEventListener('click', () => {
      switchTab('add'); // Switch to first tab
      loadBrowseFriendsModal();
    });
  }
  
  const friendsSettingsBtn = document.getElementById('friendsSettingsBtn');
  if (friendsSettingsBtn) {
    friendsSettingsBtn.addEventListener('click', openSettingsModal);
  }
  
  // Actions - with safety checks
  const createListBtn = document.getElementById('createListBtn');
  if (createListBtn) {
    createListBtn.addEventListener('click', createNewList);
  }
  
  const addProductBtn = document.getElementById('addProductBtn');
  if (addProductBtn) {
    addProductBtn.addEventListener('click', addProduct);
  }
  
  const loadHintlistBtn = document.getElementById('loadHintlistBtn');
  if (loadHintlistBtn) {
    loadHintlistBtn.addEventListener('click', loadHintlist);
  }
  
  const hintlistCodeInput = document.getElementById('hintlistCode');
  if (hintlistCodeInput) {
    hintlistCodeInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        loadHintlist();
      }
    });
  }
  
  const refreshBtn = document.getElementById('refreshListsBtn');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', async () => {
      showMessage('addMessage', 'Refreshing...', 'info');
      await loadUserData();
      showMessage('addMessage', 'Lists refreshed!', 'success');
    });
  }
  
  const createListFromMyListsBtn = document.getElementById('createListFromMyListsBtn');
  if (createListFromMyListsBtn) {
    createListFromMyListsBtn.addEventListener('click', createNewList);
  }
  
  const refreshClaimsBtn = document.getElementById('refreshClaimsBtn');
  if (refreshClaimsBtn) {
    refreshClaimsBtn.addEventListener('click', async () => {
      await loadMyClaims();
    });
  }
  
  const refreshFriendsBtn = document.getElementById('refreshFriendsBtn');
  if (refreshFriendsBtn) {
    refreshFriendsBtn.addEventListener('click', async () => {
      await loadBrowseFriends();
    });
  }
  
  const clearRecentBtn = document.getElementById('clearRecentBtn');
  if (clearRecentBtn) {
    clearRecentBtn.addEventListener('click', async () => {
      await chrome.storage.local.set({ recentFriends: [] });
      await loadBrowseFriends();
    });
  }
  
  const friendSearchInput = document.getElementById('friendSearchInput');
  if (friendSearchInput) {
    friendSearchInput.addEventListener('input', (e) => {
      filterFriends(e.target.value);
    });
  }
}

async function saveConfig() {
  console.log('saveConfig called');
  
  const url = document.getElementById('supabaseUrl').value.trim();
  const key = document.getElementById('supabaseKey').value.trim();
  
  console.log('URL:', url ? 'provided' : 'empty');
  console.log('Key:', key ? 'provided' : 'empty');
  
  if (!url || !key) {
    showMessage('configMessage', 'Please enter both URL and key', 'error');
    return;
  }
  
  if (!url.startsWith('https://') || !url.includes('.supabase.co')) {
    showMessage('configMessage', 'Please enter a valid Supabase URL', 'error');
    return;
  }
  
  try {
    await chrome.storage.local.set({ supabaseUrl: url, supabaseKey: key });
    supabaseUrl = url;
    supabaseKey = key;
    
    console.log('✅ Config saved successfully');
    showMessage('configMessage', 'Configuration saved!', 'success');
    setTimeout(() => showLogin(), 1000);
  } catch (error) {
    console.error('❌ Error saving config:', error);
    showMessage('configMessage', 'Error saving configuration', 'error');
  }
}

async function login() {
  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;
  
  if (!email || !password) {
    showMessage('loginMessage', 'Please enter email and password', 'error');
    return;
  }
  
  try {
    const response = await fetch(`${supabaseUrl}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: { 'apikey': supabaseKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    
    const data = await response.json();
    
    if (data.error) {
      showMessage('loginMessage', data.error.message || 'Login failed', 'error');
      return;
    }
    
    await chrome.storage.local.set({ session: data });
    currentUser = data.user;
    await ensureUserRecord();
    
    showMessage('loginMessage', 'Logged in successfully!', 'success');
    setTimeout(() => {
      showApp();
      loadUserData();
      autoFillCurrentPage();
    }, 500);
  } catch (error) {
    showMessage('loginMessage', 'Connection error.', 'error');
  }
}

async function signup() {
  const name = document.getElementById('signupName').value.trim();
  const email = document.getElementById('signupEmail').value.trim();
  const password = document.getElementById('signupPassword').value;
  
  if (!name || !email || !password) {
    showMessage('signupMessage', 'Please fill in all fields', 'error');
    return;
  }
  
  if (password.length < 6) {
    showMessage('signupMessage', 'Password must be at least 6 characters', 'error');
    return;
  }
  
  try {
    const response = await fetch(`${supabaseUrl}/auth/v1/signup`, {
      method: 'POST',
      headers: { 'apikey': supabaseKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, data: { name } })
    });
    
    const data = await response.json();
    
    if (data.error) {
      showMessage('signupMessage', data.error.message || 'Signup failed', 'error');
      return;
    }
    
    await chrome.storage.local.set({ session: data });
    currentUser = data.user;
    await ensureUserRecord(name);
    
    showMessage('signupMessage', 'Account created!', 'success');
    setTimeout(() => {
      showApp();
      loadUserData();
      autoFillCurrentPage();
    }, 500);
  } catch (error) {
    showMessage('signupMessage', 'Connection error.', 'error');
  }
}

async function logout() {
  await chrome.storage.local.remove('session');
  currentUser = null;
  currentLists = [];
  currentProducts = [];
  viewingListId = null;
  showLogin();
}

async function ensureUserRecord(name = null) {
  const session = await chrome.storage.local.get('session');
  const token = session.session?.access_token;
  
  if (!token || !currentUser) return;
  
  try {
    await supabaseRequest('POST', '/rest/v1/users', {
      id: currentUser.id,
      email: currentUser.email,
      name: name || currentUser.email.split('@')[0]
    }, token);
  } catch (error) {
    // User might already exist
  }
}

async function supabaseRequest(method, endpoint, body = null, token = null) {
  const session = await chrome.storage.local.get('session');
  const accessToken = token || session.session?.access_token;
  
  const headers = {
    'apikey': supabaseKey,
    'Content-Type': 'application/json'
  };
  
  if (accessToken) {
    headers['Authorization'] = `Bearer ${accessToken}`;
  }
  
  const options = { method, headers };
  
  if (body && (method === 'POST' || method === 'PATCH')) {
    options.body = JSON.stringify(body);
  }
  
  const response = await fetch(`${supabaseUrl}${endpoint}`, options);
  const responseText = await response.text();
  
  // Handle 401 Unauthorized (expired token)
  if (response.status === 401) {
    // Try to refresh the token
    const refreshed = await refreshSession();
    
    if (refreshed) {
      // Retry the request with new token
      return supabaseRequest(method, endpoint, body);
    } else {
      // Refresh failed, logout
      await logout();
      throw new Error('Session expired. Please login again.');
    }
  }
  
  if (responseText) {
    return JSON.parse(responseText);
  }
  
  return null;
}

async function refreshSession() {
  try {
    const session = await chrome.storage.local.get('session');
    const refreshToken = session.session?.refresh_token;
    
    if (!refreshToken) {
      return false;
    }
    
    const response = await fetch(`${supabaseUrl}/auth/v1/token?grant_type=refresh_token`, {
      method: 'POST',
      headers: { 
        'apikey': supabaseKey, 
        'Content-Type': 'application/json' 
      },
      body: JSON.stringify({ refresh_token: refreshToken })
    });
    
    const data = await response.json();
    
    if (data.error || !data.access_token) {
      return false;
    }
    
    // Save new session
    await chrome.storage.local.set({ session: data });
    currentUser = data.user;
    
    return true;
  } catch (error) {
    return false;
  }
}

async function autoFillCurrentPage() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab || !tab.url) return;
    
    const url = tab.url;
    const title = tab.title || '';
    
    if (url.startsWith('chrome://') || url.startsWith('chrome-extension://')) {
      return;
    }
    
    document.getElementById('productUrl').value = url;
    
    if (title && !document.getElementById('productName').value) {
      document.getElementById('productName').value = title;
    }
  } catch (error) {
    // Ignore errors on restricted pages
  }
}

async function loadUserData() {
  try {
    // Only get lists owned by the current user
    currentLists = await supabaseRequest('GET', `/rest/v1/lists?user_id=eq.${currentUser.id}&select=*&order=created_at.desc`);
    
    const productRequests = currentLists.map(list => 
      supabaseRequest('GET', `/rest/v1/products?list_id=eq.${list.id}&select=*`)
    );
    
    const allProducts = await Promise.all(productRequests);
    currentProducts = allProducts.flat();
    
    updateListsDropdown();
    displayMyLists();
  } catch (error) {
    showMessage('addMessage', 'Error loading data', 'error');
  }
}

function updateListsDropdown() {
  const select = document.getElementById('listSelect');
  select.innerHTML = '<option value="">Select a list...</option>';
  
  currentLists.forEach(list => {
    const option = document.createElement('option');
    option.value = list.id;
    option.textContent = list.name;
    select.appendChild(option);
  });
}

function displayMyLists() {
  const container = document.getElementById('myListsContainer');
  container.innerHTML = '';
  
  if (currentLists.length === 0) {
    container.innerHTML = '<div class="loading">No lists yet. Create one to get started!</div>';
    return;
  }
  
  currentLists.forEach(list => {
    const products = currentProducts.filter(p => p.list_id === list.id);
    const listDiv = document.createElement('div');
    listDiv.className = 'list-item';
    
    const headerDiv = document.createElement('div');
    headerDiv.className = 'list-header';
    
    const nameDiv = document.createElement('div');
    nameDiv.className = 'list-name';
    nameDiv.textContent = list.name;
    headerDiv.appendChild(nameDiv);
    
    const badgesDiv = document.createElement('div');
    badgesDiv.className = 'list-badges';
    
    const publicBadge = document.createElement('span');
    publicBadge.className = `badge ${list.is_public ? 'public' : 'private'}`;
    publicBadge.textContent = list.is_public ? 'Public' : 'Private';
    badgesDiv.appendChild(publicBadge);
    
    const countBadge = document.createElement('span');
    countBadge.className = 'badge count';
    countBadge.textContent = `${products.length} items`;
    badgesDiv.appendChild(countBadge);
    
    // Claimed count badge (without revealing who)
    const claimedCount = products.filter(p => p.claimed_by).length;
    if (claimedCount > 0) {
      const claimedBadge = document.createElement('span');
      claimedBadge.className = 'badge';
      claimedBadge.style.background = '#28a745';
      claimedBadge.style.color = 'white';
      claimedBadge.textContent = `${claimedCount} claimed`;
      claimedBadge.title = `${claimedCount} of ${products.length} items have been claimed by others`;
      badgesDiv.appendChild(claimedBadge);
    }
    
    // Key date badge (if set)
    if (list.key_date) {
      const keyDate = new Date(list.key_date);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      keyDate.setHours(0, 0, 0, 0);
      const daysUntil = Math.ceil((keyDate - today) / (1000 * 60 * 60 * 24));
      
      const dateBadge = document.createElement('span');
      dateBadge.className = 'badge';
      
    }
    
    headerDiv.appendChild(badgesDiv);
    listDiv.appendChild(headerDiv);
    
    // Key date on separate line below header (if set)
    if (list.key_date) {
      const keyDate = new Date(list.key_date);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      keyDate.setHours(0, 0, 0, 0);
      const daysUntil = Math.ceil((keyDate - today) / (1000 * 60 * 60 * 24));
      
      const dateLineDiv = document.createElement('div');
      dateLineDiv.style.marginBottom = '8px';
      dateLineDiv.style.fontSize = '13px';
      dateLineDiv.style.fontWeight = '600';
      
      // Color based on urgency
      if (daysUntil <= 15) {
        dateLineDiv.style.color = '#dc3545'; // red
      } else if (daysUntil <= 30) {
        dateLineDiv.style.color = '#ffc107'; // yellow  
      } else {
        dateLineDiv.style.color = '#228855'; // green
      }
      
      // Format date as m/d/yy (no leading zeros)
      const month = keyDate.getMonth() + 1;
      const day = keyDate.getDate();
      const year = keyDate.getFullYear().toString().slice(-2);
      const formattedDate = `${month}/${day}/${year}`;
      
      dateLineDiv.textContent = `📅 ${formattedDate} (${daysUntil}d)`;
      listDiv.appendChild(dateLineDiv);
    }
    
    // List actions - REORGANIZED for clarity
    const actionsDiv = document.createElement('div');
    actionsDiv.style.marginTop = '8px';
    actionsDiv.style.display = 'flex';
    actionsDiv.style.gap = '6px';
    actionsDiv.style.flexWrap = 'wrap';
    actionsDiv.style.alignItems = 'center';
    
    // PRIMARY ACTIONS (most used, always visible)
    
    // Expand/Collapse button
    const expandBtn = document.createElement('button');
    expandBtn.className = 'btn-small';
    expandBtn.style.background = '#6c757d';
    expandBtn.style.color = 'white';
    expandBtn.textContent = '▶ Expand';
    expandBtn.id = `expand-${list.id}`;
    // Note: Event listener added after products container is created
    actionsDiv.appendChild(expandBtn);
    
    // Invite button (for public lists)
    if (list.is_public) {
      const inviteQuickBtn = document.createElement('button');
      inviteQuickBtn.className = 'btn-small';
      inviteQuickBtn.style.background = '#228855';
      inviteQuickBtn.style.color = 'white';
      inviteQuickBtn.textContent = '✉️ Invite';
      inviteQuickBtn.addEventListener('click', () => openInviteModal(list));
      actionsDiv.appendChild(inviteQuickBtn);
    }
    
    // Export button
    const exportBtn = document.createElement('button');
    exportBtn.className = 'btn-small';
    exportBtn.textContent = '📥 Export';
    exportBtn.addEventListener('click', () => exportListToExcel(list, products));
    actionsDiv.appendChild(exportBtn);
    
    // SECONDARY ACTIONS DROPDOWN (⋮ More menu)
    const moreBtn = document.createElement('button');
    moreBtn.className = 'btn-small secondary';
    moreBtn.textContent = '⋮ More';
    moreBtn.style.position = 'relative';
    
    const dropdownId = `dropdown-${list.id}`;
    moreBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      // Close all other dropdowns first
      document.querySelectorAll('.actions-dropdown').forEach(d => {
        if (d.id !== dropdownId) d.remove();
      });
      
      const existing = document.getElementById(dropdownId);
      if (existing) {
        existing.remove();
        return;
      }
      
      const dropdown = document.createElement('div');
      dropdown.id = dropdownId;
      dropdown.className = 'actions-dropdown';
      dropdown.innerHTML = `
        <button class="dropdown-item" data-action="toggle">${list.is_public ? '🔒 Make Private' : '🌍 Make Public'}</button>
        <button class="dropdown-item" data-action="rename">✏️ Rename</button>
        <button class="dropdown-item" data-action="date">📅 ${list.key_date ? 'Edit Date' : 'Set Date'}</button>
        <div class="dropdown-divider"></div>
        <button class="dropdown-item danger" data-action="delete">🗑️ Delete List</button>
      `;
      
      // Smart positioning - check if dropdown will overflow bottom
      const rect = moreBtn.getBoundingClientRect();
      const dropdownHeight = 200; // Approximate height
      const spaceBelow = window.innerHeight - rect.bottom;
      const spaceAbove = rect.top;
      
      dropdown.style.position = 'fixed';
      dropdown.style.zIndex = '10000';
      
      // Position above if not enough space below
      if (spaceBelow < dropdownHeight && spaceAbove > dropdownHeight) {
        dropdown.style.bottom = `${window.innerHeight - rect.top + 4}px`;
        dropdown.style.left = `${rect.left}px`;
      } else {
        dropdown.style.top = `${rect.bottom + 4}px`;
        dropdown.style.left = `${rect.left}px`;
      }
      
      document.body.appendChild(dropdown);
      
      // Add click handlers
      dropdown.querySelectorAll('.dropdown-item').forEach(item => {
        item.addEventListener('click', async (e) => {
          e.stopPropagation();
          dropdown.remove();
          
          const action = item.dataset.action;
          switch(action) {
            case 'toggle':
              await toggleListPublic(list.id, !list.is_public);
              break;
            case 'rename':
              renameList(list.id, list.name);
              break;
            case 'date':
              setKeyDate(list.id, list.name, list.key_date);
              break;
            case 'delete':
              deleteList(list.id, list.name);
              break;
          }
        });
      });
      
      // Close on outside click
      setTimeout(() => {
        document.addEventListener('click', function closeDropdown() {
          dropdown.remove();
          document.removeEventListener('click', closeDropdown);
        });
      }, 10);
    });
    
    actionsDiv.appendChild(moreBtn);
    
    // Notification level selector (only for public lists)
    if (list.is_public) {
      const notifySelect = document.createElement('select');
      notifySelect.className = 'btn-small';
      notifySelect.style.padding = '6px 10px';
      notifySelect.style.fontSize = '12px';
      notifySelect.style.cursor = 'pointer';
      
      const notificationLevel = list.notification_level || 'none';
      
      // Set color based on level
      if (notificationLevel === 'none') {
        notifySelect.style.background = '#6c757d';
        notifySelect.style.color = 'white';
      } else {
        notifySelect.style.background = '#228855';
        notifySelect.style.color = 'white';
      }
      
      const options = [
        { value: 'none', label: '🔕 No Notifications', icon: '🔕' },
        { value: 'who_only', label: '👤 Notify Who Only', icon: '👤' },
        { value: 'what_only', label: '🎁 Notify What Only', icon: '🎁' },
        { value: 'both', label: '🔔 Notify Both', icon: '🔔' }
      ];
      
      options.forEach(opt => {
        const option = document.createElement('option');
        option.value = opt.value;
        option.textContent = opt.label;
        option.selected = notificationLevel === opt.value;
        notifySelect.appendChild(option);
      });
      
      notifySelect.title = 'Choose what to be notified about when someone claims an item';
      notifySelect.addEventListener('change', (e) => {
        toggleListNotifications(list.id, e.target.value);
      });
      
      actionsDiv.appendChild(notifySelect);
    }
    
    listDiv.appendChild(actionsDiv);
    
    // Products container (hidden by default)
    const productsContainer = document.createElement('div');
    productsContainer.id = `products-${list.id}`;
    productsContainer.style.display = 'none';
    productsContainer.style.marginTop = '12px';
    
    // Products
    products.forEach(product => {
      const productDiv = document.createElement('div');
      productDiv.className = 'product-item';
      
      // Thumbnail
      const thumbnailDiv = document.createElement('div');
      thumbnailDiv.className = 'product-thumbnail';
      if (product.image_url) {
        const img = document.createElement('img');
        img.src = product.image_url;
        img.alt = product.name;
        img.onerror = () => {
          thumbnailDiv.innerHTML = '<div class="product-thumbnail-placeholder">📦</div>';
        };
        thumbnailDiv.appendChild(img);
      } else {
        thumbnailDiv.innerHTML = '<div class="product-thumbnail-placeholder">📦</div>';
      }
      productDiv.appendChild(thumbnailDiv);
      
      // Product details container
      const detailsDiv = document.createElement('div');
      detailsDiv.className = 'product-details';
      
      const nameDiv = document.createElement('div');
      nameDiv.className = 'product-name';
      nameDiv.textContent = product.name;
      detailsDiv.appendChild(nameDiv);
      
      if (product.current_price) {
        const priceDiv = document.createElement('div');
        priceDiv.className = 'product-meta';
        priceDiv.textContent = `$${product.current_price}`;
        detailsDiv.appendChild(priceDiv);
      }
      
      if (product.url) {
        const urlDiv = document.createElement('div');
        urlDiv.className = 'product-url';
        urlDiv.textContent = product.url;
        detailsDiv.appendChild(urlDiv);
      }
      
      const productActionsDiv = document.createElement('div');
      productActionsDiv.className = 'product-actions';
      
      if (product.url) {
        const visitBtn = document.createElement('button');
        visitBtn.className = 'btn-small';
        visitBtn.textContent = 'Visit';
        visitBtn.addEventListener('click', () => window.open(product.url, '_blank'));
        productActionsDiv.appendChild(visitBtn);
      }
      
      const editProductBtn = document.createElement('button');
      editProductBtn.className = 'btn-small secondary';
      editProductBtn.textContent = 'Edit';
      editProductBtn.addEventListener('click', () => editProduct(product));
      productActionsDiv.appendChild(editProductBtn);
      
      const deleteProductBtn = document.createElement('button');
      deleteProductBtn.className = 'btn-small danger';
      deleteProductBtn.textContent = 'Remove';
      deleteProductBtn.addEventListener('click', () => deleteProduct(product.id, product.name));
      productActionsDiv.appendChild(deleteProductBtn);
      
      detailsDiv.appendChild(productActionsDiv);
      productDiv.appendChild(detailsDiv);
      productsContainer.appendChild(productDiv);
    });
    
    listDiv.appendChild(productsContainer);
    
    // Expand/collapse toggle with smooth animation
    expandBtn.addEventListener('click', () => {
      if (productsContainer.style.display === 'none') {
        productsContainer.style.display = 'block';
        // Trigger animation
        productsContainer.style.opacity = '0';
        productsContainer.style.transform = 'translateY(-8px)';
        requestAnimationFrame(() => {
          productsContainer.style.transition = 'opacity 0.2s ease, transform 0.2s ease';
          productsContainer.style.opacity = '1';
          productsContainer.style.transform = 'translateY(0)';
        });
        expandBtn.textContent = '▼ Collapse';
      } else {
        productsContainer.style.opacity = '0';
        productsContainer.style.transform = 'translateY(-8px)';
        setTimeout(() => {
          productsContainer.style.display = 'none';
          expandBtn.textContent = '▶ Expand';
        }, 200);
      }
    });
    
    container.appendChild(listDiv);
  });
}

async function createNewList() {
  showCustomModal(
    'Create New List',
    '<input type="text" id="newListName" class="modal-input" placeholder="List name (e.g., Birthday Hintlist)" autofocus>',
    async () => {
      const name = document.getElementById('newListName').value.trim();
      
      if (!name) {
        showMessage('addMessage', 'Please enter a list name', 'error');
        return;
      }
      
      try {
        await supabaseRequest('POST', '/rest/v1/lists', {
          name: name,
          user_id: currentUser.id
        });
        
        showMessage('addMessage', 'List created!', 'success');
        await loadUserData();
        hideModal();
      } catch (error) {
        showMessage('addMessage', 'Error creating list', 'error');
      }
    }
  );
}

async function addProduct() {
  const name = document.getElementById('productName').value.trim();
  const url = document.getElementById('productUrl').value.trim();
  const listId = document.getElementById('listSelect').value;
  
  if (!name) {
    showMessage('addMessage', 'Please enter a product name', 'error');
    return;
  }
  
  if (!listId) {
    showMessage('addMessage', 'Please select a list', 'error');
    return;
  }
  
  try {
    showMessage('addMessage', 'Adding product...', 'info');
    
    // Extract image from URL if provided
    let imageUrl = null;
    if (url) {
      try {
        const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndoYnF5eHRqbWJvcmRjanRxeW9xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjcwMzY0MDksImV4cCI6MjA4MjYxMjQwOX0.GiTCNNNcMVuGdd45AJbXFB6eS0a5enXoUW7nfkZPD3k';
        
        const imageResponse = await fetch(`${supabaseUrl}/functions/v1/extract-product-image`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
          },
          body: JSON.stringify({ url })
        });
        
        if (imageResponse.ok) {
          const imageData = await imageResponse.json();
          if (imageData.success && imageData.image_url) {
            imageUrl = imageData.image_url;
            console.log('Extracted image:', imageUrl);
          }
        }
      } catch (imgError) {
        console.warn('Failed to extract image, continuing without it:', imgError);
        // Continue adding product even if image extraction fails
      }
    }
    
    // Add product with image URL
    await supabaseRequest('POST', '/rest/v1/products', {
      name: name,
      url: url || null,
      image_url: imageUrl,
      list_id: listId
    });
    
    document.getElementById('productName').value = '';
    document.getElementById('productUrl').value = '';
    
    showMessage('addMessage', imageUrl ? 'Product added with image!' : 'Product added!', 'success');
    await loadUserData();
  } catch (error) {
    showMessage('addMessage', 'Error adding product', 'error');
  }
}

async function deleteProduct(id, name) {
  if (!confirm(`Delete "${name}"?`)) return;
  
  try {
    await supabaseRequest('DELETE', `/rest/v1/products?id=eq.${id}`);
    showMessage('addMessage', 'Product deleted', 'success');
    await loadUserData();
  } catch (error) {
    showMessage('addMessage', 'Error deleting product', 'error');
  }
}

async function editProduct(product) {
  showCustomModal(
    'Edit Product',
    `
      <input type="text" id="editProductName" class="modal-input" placeholder="Product name" value="${product.name}" autofocus>
      <input type="text" id="editProductUrl" class="modal-input" placeholder="Product URL" value="${product.url || ''}">
    `,
    async () => {
      const newName = document.getElementById('editProductName').value.trim();
      const newUrl = document.getElementById('editProductUrl').value.trim();
      
      if (!newName) {
        showMessage('addMessage', 'Please enter a product name', 'error');
        return;
      }
      
      try {
        await supabaseRequest('PATCH', `/rest/v1/products?id=eq.${product.id}`, {
          name: newName,
          url: newUrl || null
        });
        
        showMessage('addMessage', 'Product updated!', 'success');
        await loadUserData();
        hideModal();
      } catch (error) {
        showMessage('addMessage', 'Error updating product', 'error');
      }
    }
  );
}

async function deleteList(id, name) {
  if (!confirm(`Delete list "${name}" and all its products?`)) return;
  
  try {
    await supabaseRequest('DELETE', `/rest/v1/lists?id=eq.${id}`);
    showMessage('addMessage', 'List deleted', 'success');
    await loadUserData();
  } catch (error) {
    showMessage('addMessage', 'Error deleting list', 'error');
  }
}

async function refreshProductImages(listId, products) {
  const productsWithUrls = products.filter(p => p.url && !p.image_url);
  
  if (productsWithUrls.length === 0) {
    showMessage('addMessage', 'All products already have images or no URLs!', 'info');
    return;
  }
  
  if (!confirm(`Extract images for ${productsWithUrls.length} products? This may take a minute.`)) {
    return;
  }
  
  showMessage('addMessage', `Extracting images for ${productsWithUrls.length} products...`, 'info');
  
  let successCount = 0;
  let failCount = 0;
  
  const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndoYnF5eHRqbWJvcmRjanRxeW9xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjcwMzY0MDksImV4cCI6MjA4MjYxMjQwOX0.GiTCNNNcMVuGdd45AJbXFB6eS0a5enXoUW7nfkZPD3k';
  
  for (const product of productsWithUrls) {
    try {
      const imageResponse = await fetch(`${supabaseUrl}/functions/v1/extract-product-image`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
        },
        body: JSON.stringify({ url: product.url })
      });
      
      if (imageResponse.ok) {
        const imageData = await imageResponse.json();
        if (imageData.success && imageData.image_url) {
          // Update product with extracted image
          await supabaseRequest('PATCH', `/rest/v1/products?id=eq.${product.id}`, {
            image_url: imageData.image_url
          });
          successCount++;
          console.log(`✓ Extracted image for: ${product.name}`);
        } else {
          failCount++;
          console.log(`✗ No image found for: ${product.name}`);
        }
      } else {
        failCount++;
      }
      
      // Small delay to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 500));
      
    } catch (error) {
      failCount++;
      console.error(`Error extracting image for ${product.name}:`, error);
    }
  }
  
  showMessage('addMessage', `Images extracted! ✓ ${successCount} successful, ✗ ${failCount} failed`, 'success');
  await loadUserData();
  displayMyLists();
}

async function renameList(id, currentName) {
  showCustomModal(
    'Rename List',
    `<input type="text" id="renameListInput" class="modal-input" value="${currentName}" autofocus>`,
    async () => {
      const newName = document.getElementById('renameListInput').value.trim();
      
      if (!newName) {
        showMessage('addMessage', 'Please enter a list name', 'error');
        return;
      }
      
      try {
        await supabaseRequest('PATCH', `/rest/v1/lists?id=eq.${id}`, { name: newName });
        showMessage('addMessage', 'List renamed!', 'success');
        await loadUserData();
        hideModal();
      } catch (error) {
        showMessage('addMessage', 'Error renaming list', 'error');
      }
    }
  );
}

async function setKeyDate(id, listName, currentDate) {
  const dateValue = currentDate || '';
  const modalContent = `
    <p style="margin-bottom: 16px;">Set a key date for <strong>"${listName}"</strong> to receive reminder emails:</p>
    <div style="margin-bottom: 16px;">
      <label class="settings-label">Date</label>
      <input type="date" id="keyDateInput" class="modal-input" value="${dateValue}" autofocus>
      <div style="font-size: 12px; color: #6c757d; margin-top: 8px;">
        You'll receive reminders 60, 30, and 15 days before this date
      </div>
    </div>
    ${currentDate ? '<button id="clearDateBtn" class="secondary btn-small" style="width: 100%; margin-top: 8px;">Clear Date</button>' : ''}
  `;
  
  showCustomModal(
    '📅 Set Key Date',
    modalContent,
    async () => {
      const newDate = document.getElementById('keyDateInput').value;
      
      if (!newDate) {
        showMessage('addMessage', 'Please select a date', 'error');
        return;
      }
      
      // Validate date is in the future
      const selectedDate = new Date(newDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (selectedDate < today) {
        showMessage('addMessage', 'Please select a future date', 'error');
        return;
      }
      
      try {
        await supabaseRequest('PATCH', `/rest/v1/lists?id=eq.${id}`, { key_date: newDate });
        showMessage('addMessage', 'Key date set! You\'ll receive reminders.', 'success');
        await loadUserData();
        displayMyLists();
        hideModal();
      } catch (error) {
        showMessage('addMessage', 'Error setting date', 'error');
      }
    }
  );
  
  // Add clear button listener if it exists
  setTimeout(() => {
    const clearBtn = document.getElementById('clearDateBtn');
    if (clearBtn) {
      clearBtn.addEventListener('click', async () => {
        try {
          await supabaseRequest('PATCH', `/rest/v1/lists?id=eq.${id}`, { key_date: null });
          showMessage('addMessage', 'Key date cleared', 'success');
          await loadUserData();
          displayMyLists();
          hideModal();
        } catch (error) {
          showMessage('addMessage', 'Error clearing date', 'error');
        }
      });
    }
  }, 100);
}

async function toggleListPublic(id, makePublic) {
  try {
    await supabaseRequest('PATCH', `/rest/v1/lists?id=eq.${id}`, {
      is_public: makePublic
    });
    
    showMessage('addMessage', makePublic ? 'List is now public!' : 'List is now private', 'success');
    await loadUserData();
    updateListsDropdown();
    displayMyLists();
  } catch (error) {
    showMessage('addMessage', 'Error updating list', 'error');
  }
}

async function toggleListNotifications(id, level) {
  try {
    await supabaseRequest('PATCH', `/rest/v1/lists?id=eq.${id}`, {
      notification_level: level
    });
    
    const messages = {
      'none': 'Notifications disabled for this list',
      'who_only': 'Will notify you who claimed (but not what)',
      'what_only': 'Will notify you what was claimed (but not who)',
      'both': 'Will notify you who claimed what'
    };
    
    showMessage('addMessage', messages[level] || 'Notification preferences updated', 'success');
    await loadUserData();
    displayMyLists();
  } catch (error) {
    showMessage('addMessage', 'Error updating notifications', 'error');
  }
}

async function loadHintlist() {
  const code = document.getElementById('hintlistCode').value.trim();
  
  if (!code) {
    showMessage('hintlistMessage', 'Please enter a hintlist code', 'error');
    return;
  }
  
  try {
    // First, join the hintlist using the access code (grants access)
    const result = await supabaseRPC('join_hintlist_by_code', { code: code });
    
    if (!result.success) {
      showMessage('hintlistMessage', result.error || 'Invalid access code', 'error');
      return;
    }
    
    // Now load the list and products
    const lists = await supabaseRequest('GET', `/rest/v1/lists?id=eq.${result.list_id}&select=*`);
    
    if (lists.length === 0) {
      showMessage('hintlistMessage', 'Hintlist not found', 'error');
      return;
    }
    
    const products = await supabaseRequest('GET', `/rest/v1/products?list_id=eq.${lists[0].id}&select=*`);
    displayHintlist(lists[0], products);
    showMessage('hintlistMessage', 'Hintlist loaded! You can now claim items.', 'success');
  } catch (error) {
    showMessage('hintlistMessage', 'Error loading hintlist', 'error');
  }
}

function displayHintlist(list, products) {
  const container = document.getElementById('hintlistContainer');
  container.innerHTML = '';
  
  const available = products.filter(p => !p.claimed_by || p.claimed_by === currentUser.id);
  
  const hintlistDiv = document.createElement('div');
  hintlistDiv.className = 'list-item';
  hintlistDiv.innerHTML = `
    <div class="list-header">
      <div class="list-name">${list.name}</div>
      <div class="list-badges">
        <span class="badge count">${available.length} available</span>
      </div>
    </div>
  `;
  
  // Add export button for hintlists
  const exportHintlistBtn = document.createElement('button');
  exportHintlistBtn.className = 'btn-small';
  exportHintlistBtn.textContent = '📥 Export to Excel';
  exportHintlistBtn.style.marginTop = '8px';
  exportHintlistBtn.addEventListener('click', () => exportListToExcel(list, products));
  hintlistDiv.appendChild(exportHintlistBtn);
  
  if (available.length === 0) {
    hintlistDiv.innerHTML += '<p style="margin-top: 8px; color: #6c757d; font-size: 13px;">All items claimed!</p>';
  }
  
  available.forEach(product => {
    const isMine = product.claimed_by === currentUser.id;
    
    const productDiv = document.createElement('div');
    productDiv.className = `product-item ${isMine ? 'claimed' : ''}`;
    
    // Thumbnail
    const thumbnailDiv = document.createElement('div');
    thumbnailDiv.className = 'product-thumbnail';
    if (product.image_url) {
      const img = document.createElement('img');
      img.src = product.image_url;
      img.alt = product.name;
      img.onerror = () => {
        thumbnailDiv.innerHTML = '<div class="product-thumbnail-placeholder">📦</div>';
      };
      thumbnailDiv.appendChild(img);
    } else {
      thumbnailDiv.innerHTML = '<div class="product-thumbnail-placeholder">📦</div>';
    }
    productDiv.appendChild(thumbnailDiv);
    
    // Product details
    const detailsDiv = document.createElement('div');
    detailsDiv.className = 'product-details';
    
    const nameDiv = document.createElement('div');
    nameDiv.className = 'product-name';
    nameDiv.textContent = product.name;
    detailsDiv.appendChild(nameDiv);
    
    if (isMine) {
      const metaDiv = document.createElement('div');
      metaDiv.className = 'product-meta';
      metaDiv.textContent = '✓ You claimed this';
      detailsDiv.appendChild(metaDiv);
    }
    
    if (product.url) {
      const urlDiv = document.createElement('div');
      urlDiv.className = 'product-url';
      urlDiv.textContent = product.url;
      detailsDiv.appendChild(urlDiv);
    }
    
    const actionsDiv = document.createElement('div');
    actionsDiv.className = 'product-actions';
    
    if (product.url) {
      const visitBtn = document.createElement('button');
      visitBtn.className = 'btn-small';
      visitBtn.textContent = 'Visit';
      visitBtn.addEventListener('click', () => window.open(product.url, '_blank'));
      actionsDiv.appendChild(visitBtn);
    }
    
    if (isMine) {
      const unclaimBtn = document.createElement('button');
      unclaimBtn.className = 'btn-small danger';
      unclaimBtn.textContent = 'Unclaim';
      unclaimBtn.addEventListener('click', async () => {
        if (!confirm('Unclaim this item?')) return;
        try {
          const result = await supabaseRPC('unclaim_product', { product_id: product.id });
          if (result.success) {
            showMessage('hintlistMessage', 'Item unclaimed', 'success');
            setTimeout(() => loadHintlist(), 500);
          } else {
            showMessage('hintlistMessage', result.error || 'Error unclaiming', 'error');
          }
        } catch (error) {
          showMessage('hintlistMessage', 'Error unclaiming', 'error');
        }
      });
      actionsDiv.appendChild(unclaimBtn);
    } else {
      const claimBtn = document.createElement('button');
      claimBtn.className = 'btn-small';
      claimBtn.textContent = "I'll buy this!";
      claimBtn.addEventListener('click', async () => {
        if (!confirm('Claim this item?')) return;
        try {
          const result = await supabaseRPC('claim_product', { product_id: product.id });
          if (result.success) {
            showMessage('hintlistMessage', 'Item claimed!', 'success');
            setTimeout(() => loadHintlist(), 500);
          } else {
            showMessage('hintlistMessage', result.error || 'Error claiming', 'error');
          }
        } catch (error) {
          showMessage('hintlistMessage', 'Error claiming', 'error');
        }
      });
      actionsDiv.appendChild(claimBtn);
    }
    
    detailsDiv.appendChild(actionsDiv);
    productDiv.appendChild(detailsDiv);
    hintlistDiv.appendChild(productDiv);
  });
  
  container.appendChild(hintlistDiv);
}

// Friends Modal Functions
function openFriendsModal() {
  document.getElementById('friendsModal').classList.add('show');
  loadFriends();
}

function closeFriendsModal() {
  document.getElementById('friendsModal').classList.remove('show');
}

// Invite Modal Functions
function openInviteModal(list) {
  const shareableUrl = `https://wahans.github.io/hint/?code=${list.access_code}`;
  const userName = currentUser?.user_metadata?.name || currentUser?.name || 'Your friend';
  
  const emailSubject = encodeURIComponent(`🎁 ${userName} shared a hintlist with you!`);
  const emailBody = encodeURIComponent(`Hi!

I created a hintlist on hint and wanted to share it with you: "${list.name}"

You can view my hintlist here:
${shareableUrl}

No signup required - just click the link!

- ${userName}`);

  const smsBody = encodeURIComponent(`Hey! I shared my "${list.name}" hintlist with you on hint. Check it out: ${shareableUrl}`);
  
  const modalContent = `
    <div class="modal-header">✉️ Invite Friends</div>
    <div class="modal-body">
      <p style="margin-bottom: 16px;">Share <strong>"${list.name}"</strong> with friends and family!</p>
      
      <div class="settings-item">
        <label class="settings-label">Shareable Link</label>
        <div style="display: flex; gap: 8px;">
          <input type="text" id="inviteUrlInput" class="modal-input" value="${shareableUrl}" readonly style="flex: 1; margin: 0;">
          <button id="copyInviteLinkBtn" class="btn-small">Copy</button>
        </div>
        <div style="font-size: 12px; color: #6c757d; margin-top: 8px;">
          Anyone with this link can view your hintlist
        </div>
      </div>
      
      <div class="settings-item">
        <label class="settings-label">Send via Email</label>
        <div style="display: flex; gap: 8px;">
          <input type="email" id="inviteEmailInput" class="modal-input" placeholder="friend@example.com" style="flex: 1; margin: 0;">
          <button id="sendEmailInviteBtn" class="btn-small" style="background: #228855; color: white;">Send</button>
        </div>
        <div style="font-size: 12px; color: #6c757d; margin-top: 8px;">
          We'll send them a beautiful email with your hintlist
        </div>
      </div>
      
      <div class="settings-item">
        <label class="settings-label">Quick Share</label>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <button id="emailClientBtn" class="btn-small secondary" style="flex: 1;">
            📧 Email
          </button>
          <button id="smsBtn" class="btn-small secondary" style="flex: 1;">
            💬 SMS
          </button>
          <button id="qrCodeBtn" class="btn-small secondary" style="flex: 1;">
            📱 QR Code
          </button>
        </div>
      </div>
      
      <div id="inviteMessage" style="margin-top: 16px;"></div>
    </div>
    
    <div class="modal-buttons">
      <button id="closeInviteBtn" class="secondary">Close</button>
    </div>
  `;
  
  // Set modal content directly
  document.getElementById('modalContent').innerHTML = modalContent;
  document.getElementById('modalOverlay').classList.add('show');
  
  // Add event listeners
  document.getElementById('closeInviteBtn').addEventListener('click', hideModal);
  
  document.getElementById('copyInviteLinkBtn').addEventListener('click', () => {
    const input = document.getElementById('inviteUrlInput');
    input.select();
    navigator.clipboard.writeText(shareableUrl);
    showInviteMessage('Link copied to clipboard!', 'success');
  });
  
  document.getElementById('sendEmailInviteBtn').addEventListener('click', () => {
    sendEmailInvite(list, shareableUrl);
  });
  
  document.getElementById('emailClientBtn').addEventListener('click', () => {
    window.open(`mailto:?subject=${emailSubject}&body=${emailBody}`);
    showInviteMessage('Opening email client...', 'success');
  });
  
  document.getElementById('smsBtn').addEventListener('click', () => {
    window.open(`sms:?body=${smsBody}`);
    showInviteMessage('Opening SMS...', 'success');
  });
  
  document.getElementById('qrCodeBtn').addEventListener('click', () => {
    generateQRCode(shareableUrl, list.name);
  });
}

function showInviteMessage(text, type) {
  const el = document.getElementById('inviteMessage');
  if (el) {
    el.className = type === 'error' ? 'error-message' : 'success-message';
    el.textContent = text;
    
    setTimeout(() => {
      el.textContent = '';
      el.className = '';
    }, 3000);
  }
}

async function sendEmailInvite(list, shareableUrl) {
  const emailInput = document.getElementById('inviteEmailInput');
  const email = emailInput.value.trim();
  
  if (!email) {
    showInviteMessage('Please enter an email address', 'error');
    return;
  }
  
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    showInviteMessage('Please enter a valid email address', 'error');
    return;
  }
  
  showInviteMessage('Sending invitation...', 'info');
  
  try {
    // Get user's name from database (not from currentUser which doesn't have it)
    let userName = 'Your friend';
    try {
      const userRecord = await supabaseRequest('GET', `/rest/v1/users?id=eq.${currentUser.id}&select=name`);
      if (userRecord && userRecord.length > 0 && userRecord[0].name) {
        userName = userRecord[0].name;
      }
    } catch (nameError) {
      console.warn('Could not fetch user name from database:', nameError);
    }
    
    console.log('=== SENDING INVITE ===');
    console.log('currentUser.id:', currentUser.id);
    console.log('Fetched userName from DB:', userName);
    console.log('URL:', `${supabaseUrl}/functions/v1/send-email-invite`);
    console.log('To:', email);
    console.log('From:', userName);
    console.log('List:', list.name);
    console.log('Shareable URL:', shareableUrl);
    
    // ANON KEY - Updated automatically
    const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndoYnF5eHRqbWJvcmRjanRxeW9xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjcwMzY0MDksImV4cCI6MjA4MjYxMjQwOX0.GiTCNNNcMVuGdd45AJbXFB6eS0a5enXoUW7nfkZPD3k';
    
    // Call Edge Function to send invitation email
    const response = await fetch(`${supabaseUrl}/functions/v1/send-email-invite`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify({
        to_email: email,
        from_name: userName,
        list_name: list.name,
        shareable_url: shareableUrl
      })
    });
    
    console.log('Response status:', response.status);
    console.log('Response OK:', response.ok);
    
    let responseData;
    try {
      responseData = await response.json();
      console.log('Response data:', responseData);
    } catch (jsonError) {
      console.error('Failed to parse response as JSON:', jsonError);
      const responseText = await response.text();
      console.log('Response text:', responseText);
      throw new Error(`Server returned non-JSON response: ${responseText.substring(0, 100)}`);
    }
    
    if (response.ok) {
      showInviteMessage('Invitation sent! ✓', 'success');
      emailInput.value = '';
      
      // Track invitation in database
      await trackInvitation(email, list.id);
    } else {
      const errorMsg = responseData.error || responseData.message || 'Unknown error';
      console.error('Edge Function error:', errorMsg);
      showInviteMessage(`Error: ${errorMsg}`, 'error');
    }
  } catch (error) {
    console.error('=== ERROR SENDING INVITE ===');
    console.error('Error type:', error.name);
    console.error('Error message:', error.message);
    console.error('Full error:', error);
    
    // Show helpful error message
    if (error.message.includes('Failed to fetch')) {
      showInviteMessage('Error: Cannot reach server. Check Edge Function is deployed.', 'error');
    } else if (error.message.includes('NetworkError')) {
      showInviteMessage('Error: Network error. Check your connection.', 'error');
    } else {
      showInviteMessage(`Error: ${error.message}`, 'error');
    }
  }
}

async function trackInvitation(email, listId) {
  try {
    await supabaseRequest('POST', '/rest/v1/invitations', {
      invited_email: email,
      list_id: listId,
      inviter_id: currentUser.id,
      invited_at: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error tracking invitation:', error);
  }
}

function generateQRCode(url, listName) {
  // Show QR code in modal
  const qrContent = `
    <div class="modal-header">📱 QR Code</div>
    <div class="modal-body" style="text-align: center;">
      <p style="margin-bottom: 20px;">Scan this QR code to view <strong>"${listName}"</strong></p>
      <div id="qrcode" style="display: flex; justify-content: center; margin: 20px 0;"></div>
      <p style="font-size: 12px; color: #6c757d; margin-top: 20px;">
        Use your phone's camera app to scan
      </p>
      <button id="downloadQRBtn" class="btn-small" style="margin-top: 16px;">💾 Download QR Code</button>
    </div>
    <button id="closeQRBtn" class="secondary">Close</button>
  `;
  
  // Set modal content directly
  document.getElementById('modalContent').innerHTML = qrContent;
  document.getElementById('modalOverlay').classList.add('show');
  
  // Load QRCode.js from CDN if not already loaded
  if (typeof QRCode === 'undefined') {
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js';
    script.onload = () => renderQRCode(url, listName);
    document.head.appendChild(script);
  } else {
    renderQRCode(url, listName);
  }
  
  document.getElementById('closeQRBtn').addEventListener('click', hideModal);
}

function renderQRCode(url, listName) {
  const qrDiv = document.getElementById('qrcode');
  qrDiv.innerHTML = ''; // Clear placeholder
  
  // Generate QR code
  new QRCode(qrDiv, {
    text: url,
    width: 256,
    height: 256,
    colorDark: '#228855',
    colorLight: '#ffffff',
    correctLevel: QRCode.CorrectLevel.H
  });
  
  // Add download functionality
  setTimeout(() => {
    const downloadBtn = document.getElementById('downloadQRBtn');
    if (downloadBtn) {
      downloadBtn.addEventListener('click', () => {
        const canvas = qrDiv.querySelector('canvas');
        if (canvas) {
          const link = document.createElement('a');
          link.download = `hint-qr-${listName.replace(/[^a-z0-9]/gi, '-').toLowerCase()}.png`;
          link.href = canvas.toDataURL('image/png');
          link.click();
        }
      });
    }
  }, 100);
}

// Settings Modal Functions
async function openSettingsModal() {
  const modalContent = document.getElementById('modalContent');
  
  // Get current user info
  const userName = currentUser?.user_metadata?.name || currentUser?.name || '';
  const userEmail = currentUser?.email || '';
  
  modalContent.innerHTML = `
    <div class="modal-header">⚙️ Settings</div>
    <div class="modal-body" style="max-height: 400px; overflow-y: auto;">
      
      <!-- Account Section -->
      <div class="settings-section">
        <h3 class="settings-section-title" data-section="account">
          <span id="account-arrow">▶</span> Account
        </h3>
        <div id="account-section" class="settings-section-content hidden">
          <div class="settings-item">
            <label class="settings-label">Display Name</label>
            <div style="display: flex; gap: 8px;">
              <input type="text" id="settingsName" class="modal-input" value="${userName}" style="flex: 1; margin: 0;">
              <button id="saveNameBtn" class="btn-small">Save</button>
            </div>
          </div>
          
          <div class="settings-item">
            <label class="settings-label">Email</label>
            <input type="text" class="modal-input" value="${userEmail}" disabled style="background: #f8f9fa; cursor: not-allowed;">
            <div style="font-size: 12px; color: #6c757d; margin-top: 4px;">Email cannot be changed</div>
          </div>
          
          <div class="settings-item" style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #dee2e6;">
            <label class="settings-label">Change Password</label>
            <div style="display: flex; flex-direction: column; gap: 8px;">
              <input type="password" id="currentPassword" class="modal-input" placeholder="Current password" style="margin: 0;">
              <input type="password" id="newPassword" class="modal-input" placeholder="New password" style="margin: 0;">
              <input type="password" id="confirmNewPassword" class="modal-input" placeholder="Confirm new password" style="margin: 0;">
              <button id="changePasswordBtn" class="btn-small">Change Password</button>
            </div>
          </div>
          
          <div id="accountMessage" style="margin-top: 12px;"></div>
        </div>
      </div>
      
      <!-- Appearance Section -->
      <div class="settings-section">
        <h3 class="settings-section-title" data-section="appearance">
          <span id="appearance-arrow">▶</span> Appearance
        </h3>
        <div id="appearance-section" class="settings-section-content hidden">
          <div class="settings-item">
            <label class="settings-label">Theme</label>
            <div style="display: flex; gap: 8px;">
              <button id="lightModeBtn" class="btn-small theme-btn active" data-theme="light">
                ☀️ Light
              </button>
              <button id="darkModeBtn" class="btn-small theme-btn" data-theme="dark">
                🌙 Dark
              </button>
            </div>
            <div style="font-size: 12px; color: var(--text-secondary); margin-top: 8px;">
              Choose your preferred theme
            </div>
          </div>
        </div>
      </div>
      
      <!-- Notifications Section -->
      <div class="settings-section">
        <h3 class="settings-section-title" data-section="notifications">
          <span id="notifications-arrow">▶</span> Notifications
        </h3>
        <div id="notifications-section" class="settings-section-content hidden">
          <div class="settings-item">
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 0; vertical-align: top;">
                  <div style="font-weight: 600; margin-bottom: 4px; font-size: 13px;">Email Notifications</div>
                  <div style="font-size: 12px; color: #6c757d;">Receive email notifications from hint</div>
                </td>
                <td style="padding: 0 0 0 16px; vertical-align: top; width: 20px;">
                  <input type="checkbox" id="emailNotificationsToggle" checked>
                </td>
              </tr>
            </table>
          </div>
          
          <div class="settings-item">
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 0; vertical-align: top;">
                  <div style="font-weight: 600; margin-bottom: 4px; font-size: 13px;">Price Drop Alerts</div>
                  <div style="font-size: 12px; color: #6c757d;">Get notified when prices drop on your items</div>
                </td>
                <td style="padding: 0 0 0 16px; vertical-align: top; width: 20px;">
                  <input type="checkbox" id="priceDropToggle" checked>
                </td>
              </tr>
            </table>
          </div>
          
          <div class="settings-item">
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 0; vertical-align: top;">
                  <div style="font-weight: 600; margin-bottom: 4px; font-size: 13px;">Friend Request Notifications</div>
                  <div style="font-size: 12px; color: #6c757d;">Get notified when someone sends you a friend request</div>
                </td>
                <td style="padding: 0 0 0 16px; vertical-align: top; width: 20px;">
                  <input type="checkbox" id="friendRequestToggle" checked>
                </td>
              </tr>
            </table>
          </div>
          
          <div class="settings-item" style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #dee2e6;">
            <label class="settings-label" style="margin-bottom: 12px;">Key Date Reminders</label>
            
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 12px;">
              <tr>
                <td style="padding: 0; vertical-align: top;">
                  <div style="font-weight: 600; margin-bottom: 4px; font-size: 13px;">60-Day Reminder</div>
                  <div style="font-size: 12px; color: #6c757d;">Two months before your key date</div>
                </td>
                <td style="padding: 0 0 0 16px; vertical-align: top; width: 20px;">
                  <input type="checkbox" id="reminder60Toggle" checked>
                </td>
              </tr>
            </table>
            
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 12px;">
              <tr>
                <td style="padding: 0; vertical-align: top;">
                  <div style="font-weight: 600; margin-bottom: 4px; font-size: 13px;">30-Day Reminder</div>
                  <div style="font-size: 12px; color: #6c757d;">One month before your key date</div>
                </td>
                <td style="padding: 0 0 0 16px; vertical-align: top; width: 20px;">
                  <input type="checkbox" id="reminder30Toggle" checked>
                </td>
              </tr>
            </table>
            
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 0; vertical-align: top;">
                  <div style="font-weight: 600; margin-bottom: 4px; font-size: 13px;">15-Day Reminder</div>
                  <div style="font-size: 12px; color: #6c757d;">Two weeks before your key date</div>
                </td>
                <td style="padding: 0 0 0 16px; vertical-align: top; width: 20px;">
                  <input type="checkbox" id="reminder15Toggle" checked>
                </td>
              </tr>
            </table>
          </div>
        </div>
      </div>
      
      <!-- Data & Export Section -->
      <div class="settings-section">
        <h3 class="settings-section-title" data-section="data">
          <span id="data-arrow">▶</span> Data & Export
        </h3>
        <div id="data-section" class="settings-section-content hidden">
          <div class="settings-item">
            <label class="settings-label">Export Your Data</label>
            <div style="font-size: 12px; color: #6c757d; margin-bottom: 8px;">
              Download all your hintlists and products as a CSV file
            </div>
            <button id="exportDataBtn" class="btn-small" style="width: 100%;">
              📥 Export to CSV
            </button>
          </div>
          
          <div class="settings-item">
            <label class="settings-label">Storage Info</label>
            <div style="background: #f8f9fa; padding: 12px; border-radius: 6px; font-size: 13px;">
              <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                <span style="color: #6c757d;">Hintlists:</span>
                <span style="font-weight: 600;" id="statsLists">-</span>
              </div>
              <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                <span style="color: #6c757d;">Products:</span>
                <span style="font-weight: 600;" id="statsProducts">-</span>
              </div>
              <div style="display: flex; justify-content: space-between;">
                <span style="color: #6c757d;">Friends:</span>
                <span style="font-weight: 600;" id="statsFriends">-</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Preferences Section -->
      <div class="settings-section">
        <h3 class="settings-section-title" data-section="preferences">
          <span id="preferences-arrow">▶</span> Preferences
        </h3>
        <div id="preferences-section" class="settings-section-content hidden">
          <div class="settings-item">
            <label class="settings-label">Currency</label>
            <div style="font-size: 12px; color: #6c757d; margin-bottom: 8px;">
              Choose your preferred currency for price display
            </div>
            <select id="currencySelect" class="modal-input" style="margin: 0;">
              <option value="USD">USD - US Dollar ($)</option>
              <option value="EUR">EUR - Euro (€)</option>
              <option value="GBP">GBP - British Pound (£)</option>
              <option value="CAD">CAD - Canadian Dollar ($)</option>
              <option value="AUD">AUD - Australian Dollar ($)</option>
              <option value="JPY">JPY - Japanese Yen (¥)</option>
            </select>
          </div>
          
          <div class="settings-item">
            <label class="settings-label">Default List Visibility</label>
            <div style="font-size: 12px; color: #6c757d; margin-bottom: 8px;">
              New hintlists will be created as
            </div>
            <select id="defaultVisibilitySelect" class="modal-input" style="margin: 0;">
              <option value="private">Private (only you can see)</option>
              <option value="public">Public (shareable with access code)</option>
            </select>
          </div>
        </div>
      </div>
      
      <!-- Privacy & Security Section -->
      <div class="settings-section">
        <h3 class="settings-section-title" data-section="privacy">
          <span id="privacy-arrow">▶</span> Privacy & Security
        </h3>
        <div id="privacy-section" class="settings-section-content hidden">
          <div class="settings-item">
            <label class="settings-label">Who Can Send Friend Requests</label>
            <div style="font-size: 12px; color: #6c757d; margin-bottom: 8px;">
              Control who can add you as a friend
            </div>
            <select id="friendRequestPrivacySelect" class="modal-input" style="margin: 0;">
              <option value="anyone">Anyone</option>
              <option value="friends_of_friends">Friends of Friends</option>
              <option value="no_one">No One</option>
            </select>
          </div>
          
          <div class="settings-item">
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 0; vertical-align: top;">
                  <div style="font-weight: 600; margin-bottom: 4px; font-size: 13px;">Profile Visibility</div>
                  <div style="font-size: 12px; color: #6c757d;">Allow others to find you by email</div>
                </td>
                <td style="padding: 0 0 0 16px; vertical-align: top; width: 20px;">
                  <input type="checkbox" id="profileVisibilityToggle" checked>
                </td>
              </tr>
            </table>
          </div>
          
          <div class="settings-item">
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 0; vertical-align: top;">
                  <div style="font-weight: 600; margin-bottom: 4px; font-size: 13px;">Show in Leaderboard</div>
                  <div style="font-size: 12px; color: #6c757d;">Display your name on public leaderboards</div>
                </td>
                <td style="padding: 0 0 0 16px; vertical-align: top; width: 20px;">
                  <input type="checkbox" id="leaderboardVisibilityToggle" checked>
                </td>
              </tr>
            </table>
          </div>
          
          <div class="settings-item" style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #dee2e6;">
            <button id="deleteAccountBtn" class="btn-small danger" style="width: 100%;">
              🗑️ Delete Account
            </button>
            <div style="font-size: 11px; color: #dc3545; margin-top: 8px; text-align: center;">
              This action cannot be undone
            </div>
          </div>
        </div>
      </div>
      
      <!-- About Section -->
      <div class="settings-section">
        <h3 class="settings-section-title" data-section="about">
          <span id="about-arrow">▶</span> About
        </h3>
        <div id="about-section" class="settings-section-content hidden">
          <div class="settings-item">
            <div style="text-align: center; padding: 16px 0;">
              <div style="font-family: 'Leckerli One', cursive; font-size: 32px; color: #228855; margin-bottom: 8px;">*hint</div>
              <div style="font-size: 12px; color: #6c757d; margin-bottom: 4px;">Version 1.0.0</div>
              <div style="font-size: 11px; color: #adb5bd;">Built with ❤️ by hint team</div>
            </div>
          </div>
          
          <div class="settings-item">
            <button class="btn-small secondary" style="width: 100%; text-align: left;" onclick="window.open('https://github.com/wahans/hint', '_blank')">
              📖 Terms of Service
            </button>
          </div>
          
          <div class="settings-item">
            <button class="btn-small secondary" style="width: 100%; text-align: left;" onclick="window.open('https://github.com/wahans/hint', '_blank')">
              🔒 Privacy Policy
            </button>
          </div>
          
          <div class="settings-item">
            <button class="btn-small secondary" style="width: 100%; text-align: left;" onclick="window.open('https://github.com/wahans/hint', '_blank')">
              📜 Open Source Licenses
            </button>
          </div>
        </div>
      </div>
      
      <!-- Help & Support Section -->
      <div class="settings-section">
        <h3 class="settings-section-title" data-section="help">
          <span id="help-arrow">▶</span> Help & Support
        </h3>
        <div id="help-section" class="settings-section-content hidden">
          <div class="settings-item">
            <button class="btn-small secondary" style="width: 100%; text-align: left;" onclick="window.open('https://github.com/wahans/hint/issues', '_blank')">
              🐛 Report a Bug
            </button>
          </div>
          
          <div class="settings-item">
            <button class="btn-small secondary" style="width: 100%; text-align: left;" onclick="window.open('https://github.com/wahans/hint/discussions', '_blank')">
              💡 Request a Feature
            </button>
          </div>
          
          <div class="settings-item">
            <button class="btn-small secondary" style="width: 100%; text-align: left;" onclick="window.open('mailto:support@hint.com', '_blank')">
              📧 Contact Support
            </button>
          </div>
          
          <div class="settings-item" style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #dee2e6;">
            <div style="font-size: 12px; color: #6c757d; text-align: center;">
              <div style="margin-bottom: 4px;">hint Extension</div>
              <div style="font-weight: 600; color: #228855;">Version 1.0.0</div>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Quick Actions Section -->
      <div class="settings-section">
        <h3 class="settings-section-title" data-section="actions">
          <span id="actions-arrow">▶</span> Quick Actions
        </h3>
        <div id="actions-section" class="settings-section-content hidden">
          <div class="settings-item">
            <button id="clearRecentBtn" class="secondary btn-small" style="width: 100%;">
              🗑️ Clear Recently Viewed Friends
            </button>
          </div>
          
          <div class="settings-item">
            <button id="signOutFromSettingsBtn" class="secondary btn-small" style="width: 100%;">
              🚪 Sign Out
            </button>
          </div>
        </div>
      </div>
      
      <div id="settingsMessage" style="margin-top: 16px;"></div>
    </div>
    
    <button id="closeSettingsBtn" class="secondary">Close</button>
  `;
  
  document.getElementById('modalOverlay').classList.add('show');
  
  // Add event listeners
  document.getElementById('closeSettingsBtn').addEventListener('click', hideModal);
  document.getElementById('saveNameBtn').addEventListener('click', saveDisplayName);
  document.getElementById('changePasswordBtn').addEventListener('click', changePassword);
  document.getElementById('clearRecentBtn').addEventListener('click', clearRecentFriends);
  document.getElementById('signOutFromSettingsBtn').addEventListener('click', logout);
  document.getElementById('exportDataBtn').addEventListener('click', exportAllData);
  document.getElementById('deleteAccountBtn').addEventListener('click', deleteAccount);
  
  // Preference selects
  document.getElementById('currencySelect').addEventListener('change', saveCurrencyPreference);
  document.getElementById('defaultVisibilitySelect').addEventListener('change', saveDefaultVisibility);
  
  // Privacy settings
  document.getElementById('friendRequestPrivacySelect').addEventListener('change', savePrivacySettings);
  document.getElementById('profileVisibilityToggle').addEventListener('change', savePrivacySettings);
  document.getElementById('leaderboardVisibilityToggle').addEventListener('change', savePrivacySettings);
  
  // Add click listeners to all section titles
  document.querySelectorAll('.settings-section-title').forEach(title => {
    title.addEventListener('click', function() {
      const sectionName = this.getAttribute('data-section');
      toggleSettingsSection(sectionName);
    });
  });
  
  // Theme button listeners - FUNCTIONAL DARK MODE!
  document.querySelectorAll('.theme-btn').forEach(btn => {
    btn.addEventListener('click', async function() {
      const theme = this.getAttribute('data-theme');
      
      // Update active button
      document.querySelectorAll('.theme-btn').forEach(b => b.classList.remove('active'));
      this.classList.add('active');
      
      // Apply theme
      document.documentElement.setAttribute('data-theme', theme);
      
      // Save preference
      await chrome.storage.local.set({ theme });
      
      showSettingsMessage(`${theme === 'dark' ? '🌙' : '☀️'} ${theme.charAt(0).toUpperCase() + theme.slice(1)} mode activated!`, 'success');
    });
  });
  
  // Load current notification preferences
  loadNotificationPreferences();
  
  // Load stats
  loadUserStats();
  
  // Load currency and visibility preferences
  loadPreferences();
  
  // Load privacy settings
  loadPrivacySettings();
  
  // Load theme preference
  loadThemePreference();
  
  // Add listeners for notification toggles
  document.getElementById('emailNotificationsToggle').addEventListener('change', saveNotificationPreferences);
  document.getElementById('priceDropToggle').addEventListener('change', saveNotificationPreferences);
  document.getElementById('friendRequestToggle').addEventListener('change', saveNotificationPreferences);
  document.getElementById('reminder60Toggle').addEventListener('change', saveNotificationPreferences);
  document.getElementById('reminder30Toggle').addEventListener('change', saveNotificationPreferences);
  document.getElementById('reminder15Toggle').addEventListener('change', saveNotificationPreferences);
}

function toggleSettingsSection(sectionName) {
  const section = document.getElementById(`${sectionName}-section`);
  const arrow = document.getElementById(`${sectionName}-arrow`);
  
  if (section && arrow) {
    if (section.classList.contains('hidden')) {
      section.classList.remove('hidden');
      arrow.textContent = '▼';
    } else {
      section.classList.add('hidden');
      arrow.textContent = '▶';
    }
  }
}

async function saveDisplayName() {
  const newName = document.getElementById('settingsName').value.trim();
  
  if (!newName) {
    showAccountMessage('Please enter a name', 'error');
    return;
  }
  
  try {
    // Update in Supabase users table
    await supabaseRequest('PATCH', `/rest/v1/users?id=eq.${currentUser.id}`, {
      name: newName
    });
    
    // Update local user object
    if (currentUser.user_metadata) {
      currentUser.user_metadata.name = newName;
    } else {
      currentUser.name = newName;
    }
    
    // Update display in header
    showApp();
    
    showAccountMessage('Name saved!', 'success');
  } catch (error) {
    console.error('Error updating name:', error);
    showAccountMessage('Error updating name', 'error');
  }
}

async function changePassword() {
  const currentPassword = document.getElementById('currentPassword').value;
  const newPassword = document.getElementById('newPassword').value;
  const confirmNewPassword = document.getElementById('confirmNewPassword').value;
  
  if (!currentPassword || !newPassword || !confirmNewPassword) {
    showAccountMessage('Please fill in all password fields', 'error');
    return;
  }
  
  if (newPassword.length < 6) {
    showAccountMessage('New password must be at least 6 characters', 'error');
    return;
  }
  
  if (newPassword !== confirmNewPassword) {
    showAccountMessage('New passwords do not match', 'error');
    return;
  }
  
  try {
    showAccountMessage('Changing password...', 'info');
    
    // Use Supabase auth API to change password
    // Note: This requires the user to be authenticated and have a valid session
    const response = await fetch(`${supabaseUrl}/auth/v1/user`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'apikey': await chrome.storage.local.get('supabase_anon_key').then(r => r.supabase_anon_key),
        'Authorization': `Bearer ${await chrome.storage.local.get('session_token').then(r => r.session_token)}`
      },
      body: JSON.stringify({
        password: newPassword
      })
    });
    
    if (response.ok) {
      // Clear password fields
      document.getElementById('currentPassword').value = '';
      document.getElementById('newPassword').value = '';
      document.getElementById('confirmNewPassword').value = '';
      
      showAccountMessage('Password changed successfully!', 'success');
    } else {
      const error = await response.json();
      showAccountMessage(error.message || 'Error changing password', 'error');
    }
  } catch (error) {
    console.error('Error changing password:', error);
    showAccountMessage('Error changing password. Please try again.', 'error');
  }
}

function showAccountMessage(text, type) {
  const el = document.getElementById('accountMessage');
  if (el) {
    el.className = type === 'error' ? 'error-message' : 'success-message';
    el.textContent = text;
    
    setTimeout(() => {
      el.textContent = '';
      el.className = '';
    }, 3000);
  }
}

async function loadNotificationPreferences() {
  try {
    const prefs = await chrome.storage.local.get([
      'emailNotifications', 
      'priceDropNotifications', 
      'friendRequestNotifications',
      'reminder60Days',
      'reminder30Days',
      'reminder15Days'
    ]);
    
    document.getElementById('emailNotificationsToggle').checked = prefs.emailNotifications !== false;
    document.getElementById('priceDropToggle').checked = prefs.priceDropNotifications !== false;
    document.getElementById('friendRequestToggle').checked = prefs.friendRequestNotifications !== false;
    document.getElementById('reminder60Toggle').checked = prefs.reminder60Days !== false;
    document.getElementById('reminder30Toggle').checked = prefs.reminder30Days !== false;
    document.getElementById('reminder15Toggle').checked = prefs.reminder15Days !== false;
  } catch (error) {
    console.error('Error loading preferences:', error);
  }
}

async function saveNotificationPreferences() {
  try {
    const emailNotifications = document.getElementById('emailNotificationsToggle').checked;
    const priceDropNotifications = document.getElementById('priceDropToggle').checked;
    const friendRequestNotifications = document.getElementById('friendRequestToggle').checked;
    const reminder60Days = document.getElementById('reminder60Toggle').checked;
    const reminder30Days = document.getElementById('reminder30Toggle').checked;
    const reminder15Days = document.getElementById('reminder15Toggle').checked;
    
    await chrome.storage.local.set({
      emailNotifications,
      priceDropNotifications,
      friendRequestNotifications,
      reminder60Days,
      reminder30Days,
      reminder15Days
    });
    
    // Also update in database
    await supabaseRequest('PATCH', `/rest/v1/users?id=eq.${currentUser.id}`, {
      email_notifications_enabled: emailNotifications,
      price_drop_notifications: priceDropNotifications,
      friend_request_notifications: friendRequestNotifications,
      reminder_60_days: reminder60Days,
      reminder_30_days: reminder30Days,
      reminder_15_days: reminder15Days
    });
    
    showSettingsMessage('Preferences saved', 'success');
  } catch (error) {
    console.error('Error saving preferences:', error);
    showSettingsMessage('Error saving preferences', 'error');
  }
}

async function clearRecentFriends() {
  if (confirm('Clear recently viewed friends?')) {
    try {
      await chrome.storage.local.set({ recentFriends: [] });
      showSettingsMessage('Recently viewed friends cleared', 'success');
    } catch (error) {
      console.error('Error clearing recent friends:', error);
      showSettingsMessage('Error clearing recent friends', 'error');
    }
  }
}

function showSettingsMessage(text, type) {
  const el = document.getElementById('settingsMessage');
  if (el) {
    el.className = type === 'error' ? 'error-message' : 'success-message';
    el.textContent = text;
    
    setTimeout(() => {
      el.textContent = '';
      el.className = '';
    }, 3000);
  }
}

async function exportAllData() {
  try {
    showSettingsMessage('Preparing export...', 'info');
    
    // Gather all data
    const lists = currentLists || [];
    const products = currentProducts || [];
    
    // Create CSV content
    let csv = 'List Name,Product Name,URL,Current Price,Claimed,Created At\n';
    
    lists.forEach(list => {
      const listProducts = products.filter(p => p.list_id === list.id);
      
      if (listProducts.length === 0) {
        // Include empty lists
        csv += `"${list.name}",,,,,${list.created_at}\n`;
      } else {
        listProducts.forEach(product => {
          csv += `"${list.name}","${product.name}","${product.url || ''}","${product.current_price || ''}","${product.claimed_by ? 'Yes' : 'No'}","${product.created_at}"\n`;
        });
      }
    });
    
    // Create download
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `hint-export-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    
    showSettingsMessage('Export complete!', 'success');
  } catch (error) {
    console.error('Error exporting data:', error);
    showSettingsMessage('Error exporting data', 'error');
  }
}

async function loadUserStats() {
  try {
    const lists = currentLists || [];
    const products = currentProducts || [];
    
    // Get friends count
    const friends = await supabaseRPC('get_friends', {});
    
    document.getElementById('statsLists').textContent = lists.length;
    document.getElementById('statsProducts').textContent = products.length;
    document.getElementById('statsFriends').textContent = friends?.length || 0;
  } catch (error) {
    console.error('Error loading stats:', error);
  }
}

async function loadPreferences() {
  try {
    const prefs = await chrome.storage.local.get(['currency', 'defaultVisibility']);
    
    if (prefs.currency) {
      document.getElementById('currencySelect').value = prefs.currency;
    }
    
    if (prefs.defaultVisibility) {
      document.getElementById('defaultVisibilitySelect').value = prefs.defaultVisibility;
    }
  } catch (error) {
    console.error('Error loading preferences:', error);
  }
}

async function saveCurrencyPreference() {
  try {
    const currency = document.getElementById('currencySelect').value;
    await chrome.storage.local.set({ currency });
    showSettingsMessage('Currency preference saved', 'success');
  } catch (error) {
    console.error('Error saving currency:', error);
    showSettingsMessage('Error saving currency', 'error');
  }
}

async function saveDefaultVisibility() {
  try {
    const defaultVisibility = document.getElementById('defaultVisibilitySelect').value;
    await chrome.storage.local.set({ defaultVisibility });
    showSettingsMessage('Default visibility saved', 'success');
  } catch (error) {
    console.error('Error saving visibility:', error);
    showSettingsMessage('Error saving visibility', 'error');
  }
}

async function loadPrivacySettings() {
  try {
    const prefs = await chrome.storage.local.get(['friendRequestPrivacy', 'profileVisibility', 'leaderboardVisibility']);
    
    if (prefs.friendRequestPrivacy) {
      document.getElementById('friendRequestPrivacySelect').value = prefs.friendRequestPrivacy;
    }
    
    document.getElementById('profileVisibilityToggle').checked = prefs.profileVisibility !== false;
    document.getElementById('leaderboardVisibilityToggle').checked = prefs.leaderboardVisibility !== false;
  } catch (error) {
    console.error('Error loading privacy settings:', error);
  }
}

async function loadThemePreference() {
  try {
    const { theme } = await chrome.storage.local.get('theme');
    
    // Update button states
    document.querySelectorAll('.theme-btn').forEach(btn => {
      btn.classList.remove('active');
      if (btn.getAttribute('data-theme') === (theme || 'light')) {
        btn.classList.add('active');
      }
    });
  } catch (error) {
    console.error('Error loading theme preference:', error);
  }
}

async function savePrivacySettings() {
  try {
    const friendRequestPrivacy = document.getElementById('friendRequestPrivacySelect').value;
    const profileVisibility = document.getElementById('profileVisibilityToggle').checked;
    const leaderboardVisibility = document.getElementById('leaderboardVisibilityToggle').checked;
    
    await chrome.storage.local.set({
      friendRequestPrivacy,
      profileVisibility,
      leaderboardVisibility
    });
    
    showSettingsMessage('Privacy settings saved', 'success');
  } catch (error) {
    console.error('Error saving privacy settings:', error);
    showSettingsMessage('Error saving privacy settings', 'error');
  }
}

async function deleteAccount() {
  const confirmation = prompt('This will permanently delete your account and all data. Type DELETE to confirm:');
  
  if (confirmation !== 'DELETE') {
    showSettingsMessage('Account deletion cancelled', 'info');
    return;
  }
  
  const finalConfirmation = confirm('Are you absolutely sure? This cannot be undone.');
  
  if (!finalConfirmation) {
    showSettingsMessage('Account deletion cancelled', 'info');
    return;
  }
  
  try {
    showSettingsMessage('Deleting account...', 'info');
    
    // Delete user data from database
    await supabaseRequest('DELETE', `/rest/v1/users?id=eq.${currentUser.id}`);
    
    // Clear local storage
    await chrome.storage.local.clear();
    
    // Show goodbye message
    alert('Your account has been deleted. Thank you for using hint!');
    
    // Reload to show login screen
    window.location.reload();
  } catch (error) {
    console.error('Error deleting account:', error);
    showSettingsMessage('Error deleting account. Please contact support.', 'error');
  }
}

function switchFriendsTab(tab) {
  // Update tab buttons
  document.getElementById('myFriendsTab').classList.remove('active');
  document.getElementById('requestsTab').classList.remove('active');
  document.getElementById('addFriendTab').classList.remove('active');
  
  // Hide all views
  document.getElementById('myFriendsView').classList.add('hidden');
  document.getElementById('requestsView').classList.add('hidden');
  document.getElementById('addFriendView').classList.add('hidden');
  
  // Show selected view
  if (tab === 'friends') {
    document.getElementById('myFriendsTab').classList.add('active');
    document.getElementById('myFriendsView').classList.remove('hidden');
    loadFriends();
  } else if (tab === 'requests') {
    document.getElementById('requestsTab').classList.add('active');
    document.getElementById('requestsView').classList.remove('hidden');
    loadPendingRequests();
  } else if (tab === 'add') {
    document.getElementById('addFriendTab').classList.add('active');
    document.getElementById('addFriendView').classList.remove('hidden');
  }
}

async function loadFriends() {
  const container = document.getElementById('friendsList');
  container.innerHTML = '<div class="loading">Loading friends...</div>';
  
  try {
    const friends = await supabaseRPC('get_friends', {});
    
    if (friends.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">👥</div>
          <div>No friends yet</div>
          <div style="font-size: 12px; margin-top: 8px;">Add friends to share hintlists!</div>
        </div>
      `;
      return;
    }
    
    container.innerHTML = '';
    
    friends.forEach(friend => {
      const friendDiv = document.createElement('div');
      friendDiv.className = 'friend-item';
      
      friendDiv.innerHTML = `
        <div class="friend-info">
          <div>
            <div class="friend-name">${friend.friend_name}</div>
            <div class="friend-email">${friend.friend_email}</div>
          </div>
        </div>
      `;
      
      const actionsDiv = document.createElement('div');
      actionsDiv.className = 'friend-actions';
      
      const viewListsBtn = document.createElement('button');
      viewListsBtn.className = 'btn-small';
      viewListsBtn.textContent = 'View Lists';
      viewListsBtn.addEventListener('click', () => viewFriendLists(friend.friend_id, friend.friend_name));
      actionsDiv.appendChild(viewListsBtn);
      
      friendDiv.querySelector('.friend-info').appendChild(actionsDiv);
      container.appendChild(friendDiv);
    });
  } catch (error) {
    container.innerHTML = '<div class="empty-state">Error loading friends</div>';
  }
}

async function loadPendingRequests() {
  const container = document.getElementById('requestsList');
  container.innerHTML = '<div class="loading">Loading requests...</div>';
  
  try {
    const requests = await supabaseRPC('get_pending_requests', {});
    
    if (requests.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">📬</div>
          <div>No pending requests</div>
        </div>
      `;
      return;
    }
    
    container.innerHTML = '';
    
    requests.forEach(request => {
      const requestDiv = document.createElement('div');
      requestDiv.className = 'friend-item';
      
      requestDiv.innerHTML = `
        <div class="friend-info">
          <div>
            <div class="friend-name">${request.requester_name}</div>
            <div class="friend-email">${request.requester_email}</div>
          </div>
        </div>
      `;
      
      const actionsDiv = document.createElement('div');
      actionsDiv.className = 'friend-actions';
      
      const acceptBtn = document.createElement('button');
      acceptBtn.className = 'btn-small';
      acceptBtn.textContent = 'Accept';
      acceptBtn.addEventListener('click', () => acceptFriendRequest(request.request_id));
      actionsDiv.appendChild(acceptBtn);
      
      const rejectBtn = document.createElement('button');
      rejectBtn.className = 'btn-small danger';
      rejectBtn.textContent = 'Reject';
      rejectBtn.addEventListener('click', () => rejectFriendRequest(request.request_id));
      actionsDiv.appendChild(rejectBtn);
      
      requestDiv.querySelector('.friend-info').appendChild(actionsDiv);
      container.appendChild(requestDiv);
    });
  } catch (error) {
    container.innerHTML = '<div class="empty-state">Error loading requests</div>';
  }
}

async function sendFriendRequest() {
  const email = document.getElementById('friendEmail').value.trim();
  
  if (!email) {
    showMessage('addFriendMessage', 'Please enter an email address', 'error');
    return;
  }
  
  if (email === currentUser.email) {
    showMessage('addFriendMessage', 'You cannot add yourself as a friend', 'error');
    return;
  }
  
  try {
    const result = await supabaseRPC('send_friend_request', { friend_email: email });
    
    if (result.success) {
      showMessage('addFriendMessage', 'Friend request sent!', 'success');
      document.getElementById('friendEmail').value = '';
    } else {
      showMessage('addFriendMessage', result.error || 'Failed to send request', 'error');
    }
  } catch (error) {
    showMessage('addFriendMessage', 'Error sending request', 'error');
  }
}

async function acceptFriendRequest(requestId) {
  try {
    const result = await supabaseRPC('accept_friend_request', { request_id: requestId });
    
    if (result.success) {
      showMessage('addFriendMessage', 'Friend request accepted!', 'success');
      loadPendingRequests();
      switchFriendsTab('friends');
    } else {
      showMessage('addFriendMessage', result.error || 'Failed to accept request', 'error');
    }
  } catch (error) {
    showMessage('addFriendMessage', 'Error accepting request', 'error');
  }
}

async function rejectFriendRequest(requestId) {
  if (!confirm('Reject this friend request?')) return;
  
  try {
    const result = await supabaseRPC('reject_friend_request', { request_id: requestId });
    
    if (result.success) {
      showMessage('addFriendMessage', 'Request rejected', 'success');
      loadPendingRequests();
    } else {
      showMessage('addFriendMessage', result.error || 'Failed to reject request', 'error');
    }
  } catch (error) {
    showMessage('addFriendMessage', 'Error rejecting request', 'error');
  }
}

async function viewFriendLists(friendId, friendName) {
  // Close any open modals
  hideModal();
  const friendsModal = document.getElementById('friendsModal');
  if (friendsModal) {
    friendsModal.classList.remove('show');
  }
  
  // Show custom modal with friend's lists
  const modalContent = document.getElementById('modalContent');
  modalContent.innerHTML = `
    <div class="modal-header">👥 ${friendName}'s Hintlists</div>
    <div id="friendListsContainer" class="modal-body" style="max-height: 350px; overflow-y: auto;">
      <div class="loading">Loading hintlists...</div>
    </div>
    <button id="closeFriendListsBtn" class="secondary">Close</button>
  `;
  
  document.getElementById('modalOverlay').classList.add('show');
  document.getElementById('closeFriendListsBtn').addEventListener('click', hideModal);
  
  try {
    // Get friend's public lists
    const result = await supabaseRPC('get_friends_public_lists', {});
    
    // Handle if result is not an array or is null
    const allLists = Array.isArray(result) ? result : (result ? [result] : []);
    
    console.log('All public lists from friends:', allLists);
    
    // Get friend's email
    const friendEmail = await getUserEmailById(friendId);
    console.log('Looking for friend email:', friendEmail);
    
    // Filter for this specific friend
    const friendLists = allLists.filter(list => {
      console.log('Comparing:', list.friend_email, 'with', friendEmail);
      return list.friend_email === friendEmail;
    });
    
    console.log('Filtered friend lists:', friendLists);
    
    const container = document.getElementById('friendListsContainer');
    
    // If no lists found via get_friends_public_lists, try getting them directly
    if (friendLists.length === 0) {
      // Alternative: Get all public lists from this specific friend
      const directLists = await supabaseRequest('GET', `/rest/v1/lists?user_id=eq.${friendId}&is_public=eq.true&select=*`);
      console.log('Direct lists query result:', directLists);
      
      if (directLists && directLists.length > 0) {
        // We found public lists! Now check if we have access
        const listsWithAccess = await Promise.all(directLists.map(async (list) => {
          try {
            const access = await supabaseRequest('GET', `/rest/v1/hintlist_access?list_id=eq.${list.id}&user_id=eq.${currentUser.id}&select=*`);
            return {
              list_id: list.id,
              list_name: list.name,
              item_count: 0, // We'll get this separately if needed
              has_access: access && access.length > 0
            };
          } catch (err) {
            return {
              list_id: list.id,
              list_name: list.name,
              item_count: 0,
              has_access: false
            };
          }
        }));
        
        // Use these lists instead
        displayFriendListsInModal(listsWithAccess, friendName, container);
        return;
      }
    }
    
    if (friendLists.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">📋</div>
          <div>${friendName} hasn't shared any hintlists yet</div>
        </div>
      `;
      return;
    }
    
    displayFriendListsInModal(friendLists, friendName, container);
  } catch (error) {
    console.error('Error in viewFriendLists:', error);
    const container = document.getElementById('friendListsContainer');
    container.innerHTML = `<div class="empty-state">Error loading hintlists: ${error.message}</div>`;
  }
}

function displayFriendListsInModal(friendLists, friendName, container) {
  container.innerHTML = '';
  
  friendLists.forEach(list => {
    const listDiv = document.createElement('div');
    listDiv.className = 'list-item';
    listDiv.style.marginBottom = '12px';
    
    listDiv.innerHTML = `
      <div class="list-header">
        <div class="list-name">${list.list_name}</div>
        <div class="list-badges">
          <span class="badge count">${list.item_count || 0} items</span>
          ${list.has_access ? '<span class="badge public">Access granted</span>' : ''}
        </div>
      </div>
    `;
    
    const actionsDiv = document.createElement('div');
    actionsDiv.style.marginTop = '12px';
    actionsDiv.style.display = 'flex';
    actionsDiv.style.gap = '8px';
    
    if (list.has_access) {
      // User already has access - can view the list
      const viewBtn = document.createElement('button');
      viewBtn.className = 'btn-small';
      viewBtn.textContent = 'View Items';
      viewBtn.addEventListener('click', () => {
        hideModal();
        viewSharedList(list.list_id, list.list_name);
      });
      actionsDiv.appendChild(viewBtn);
    } else {
      // User needs to request access
      const requestBtn = document.createElement('button');
      requestBtn.className = 'btn-small';
      requestBtn.textContent = 'Request Access';
      requestBtn.addEventListener('click', async () => {
        if (confirm(`Request access to "${list.list_name}"?`)) {
          const code = prompt(`Enter the access code for "${list.list_name}":`);
          if (code) {
            console.log('Attempting to join with code:', code.trim());
            try {
              const result = await supabaseRPC('join_hintlist_by_code', { code: code.trim() });
              console.log('join_hintlist_by_code result:', result);
              
              if (result && result.success) {
                showMessage('addMessage', 'Access granted!', 'success');
                hideModal();
                viewSharedList(list.list_id, list.list_name);
              } else {
                console.error('Access denied:', result);
                alert(result?.error || 'Invalid access code');
              }
            } catch (error) {
              console.error('Error joining hintlist:', error);
              alert(`Error: ${error.message}`);
            }
          }
        }
      });
      actionsDiv.appendChild(requestBtn);
    }
    
    listDiv.appendChild(actionsDiv);
    container.appendChild(listDiv);
  });
}

async function getUserEmailById(userId) {
  // Helper to get email from user ID
  try {
    const users = await supabaseRequest('GET', `/rest/v1/users?id=eq.${userId}&select=email`);
    return users[0]?.email || '';
  } catch (error) {
    return '';
  }
}

async function viewSharedList(listId, listName) {
  // Switch to View Hintlist tab and display the shared list
  switchTab('viewHintlist');
  
  const container = document.getElementById('hintlistContainer');
  container.innerHTML = '<div class="loading">Loading hintlist...</div>';
  
  try {
    const lists = await supabaseRequest('GET', `/rest/v1/lists?id=eq.${listId}&select=*`);
    
    if (lists.length === 0) {
      container.innerHTML = '<div class="empty-state">Hintlist not found</div>';
      return;
    }
    
    const products = await supabaseRequest('GET', `/rest/v1/products?list_id=eq.${listId}&select=*`);
    displayHintlist(lists[0], products);
    
    showMessage('hintlistMessage', `Viewing "${listName}"`, 'info');
  } catch (error) {
    container.innerHTML = '<div class="empty-state">Error loading hintlist</div>';
  }
}

async function loadBrowseFriendsModal() {
  const modalContent = document.getElementById('modalContent');
  modalContent.innerHTML = `
    <div class="modal-header">👥 Browse Friends</div>
    <div class="modal-body">
      <div style="position: relative; margin-bottom: 16px;">
        <input type="text" id="friendSearchModal" class="modal-input" placeholder="🔍 Search by name..." style="margin-bottom: 0;">
        <div id="searchDropdown" style="position: absolute; width: 100%; background: white; border: 2px solid #dee2e6; border-top: none; border-radius: 0 0 6px 6px; max-height: 200px; overflow-y: auto; display: none; z-index: 1000;"></div>
      </div>
      
      <div id="recentFriendsModalSection" style="margin-bottom: 16px;" class="hidden">
        <h3 style="font-size: 13px; color: #6c757d; margin-bottom: 8px; font-weight: 600;">⏱️ RECENTLY VIEWED</h3>
        <div id="recentFriendsModalContainer"></div>
      </div>
      
      <h3 style="font-size: 13px; color: #6c757d; margin-bottom: 8px; font-weight: 600;">👥 ALL FRIENDS</h3>
      <div id="allFriendsModalContainer" style="max-height: 250px; overflow-y: auto;">
        <div class="loading">Loading friends...</div>
      </div>
    </div>
    <button id="closeBrowseFriendsBtn" class="secondary">Close</button>
  `;
  
  document.getElementById('modalOverlay').classList.add('show');
  document.getElementById('closeBrowseFriendsBtn').addEventListener('click', hideModal);
  
  // Load friends data
  try {
    const friends = await supabaseRPC('get_friends', {});
    window.currentFriends = friends;
    
    if (friends.length === 0) {
      document.getElementById('allFriendsModalContainer').innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">👥</div>
          <div>No friends yet</div>
        </div>
      `;
      return;
    }
    
    // Load recent friends
    const { recentFriends = [] } = await chrome.storage.local.get('recentFriends');
    const recentFriendData = recentFriends
      .map(id => friends.find(f => f.friend_id === id))
      .filter(f => f !== undefined)
      .slice(0, 3);
    
    if (recentFriendData.length > 0) {
      document.getElementById('recentFriendsModalSection').classList.remove('hidden');
      const recentContainer = document.getElementById('recentFriendsModalContainer');
      recentContainer.innerHTML = '';
      recentFriendData.forEach(friend => {
        recentContainer.appendChild(createFriendCard(friend));
      });
    }
    
    // Display all friends
    displayAllFriendsInModal(friends);
    
    // Setup search with dropdown and real-time filtering
    setupFriendSearch(friends);
    
  } catch (error) {
    document.getElementById('allFriendsModalContainer').innerHTML = '<div class="empty-state">Error loading friends</div>';
  }
}

function displayAllFriendsInModal(friends) {
  const container = document.getElementById('allFriendsModalContainer');
  container.innerHTML = '';
  
  friends.forEach(friend => {
    const friendDiv = createFriendCard(friend);
    friendDiv.dataset.friendName = friend.friend_name.toLowerCase();
    container.appendChild(friendDiv);
  });
}

function setupFriendSearch(friends) {
  const searchInput = document.getElementById('friendSearchModal');
  const dropdown = document.getElementById('searchDropdown');
  const allFriendsContainer = document.getElementById('allFriendsModalContainer');
  const recentSection = document.getElementById('recentFriendsModalSection');
  
  searchInput.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase().trim();
    
    if (!term) {
      // Hide dropdown, show all friends
      dropdown.style.display = 'none';
      allFriendsContainer.querySelectorAll('.friend-item').forEach(card => {
        card.style.display = 'block';
      });
      if (recentSection) {
        recentSection.classList.remove('hidden');
        document.getElementById('recentFriendsModalContainer').querySelectorAll('.friend-item').forEach(card => {
          card.style.display = 'block';
        });
      }
      return;
    }
    
    // Show dropdown with matching friends
    const matches = friends.filter(f => f.friend_name.toLowerCase().includes(term));
    
    if (matches.length > 0) {
      dropdown.innerHTML = '';
      matches.forEach(friend => {
        const item = document.createElement('div');
        item.style.padding = '10px';
        item.style.cursor = 'pointer';
        item.style.borderBottom = '1px solid #dee2e6';
        item.textContent = friend.friend_name;
        item.addEventListener('click', async () => {
          searchInput.value = '';
          dropdown.style.display = 'none';
          await addToRecentFriends(friend.friend_id);
          hideModal();
          viewFriendLists(friend.friend_id, friend.friend_name);
        });
        item.addEventListener('mouseenter', () => {
          item.style.background = '#f8f9fa';
        });
        item.addEventListener('mouseleave', () => {
          item.style.background = 'white';
        });
        dropdown.appendChild(item);
      });
      dropdown.style.display = 'block';
    } else {
      dropdown.style.display = 'none';
    }
    
    // Real-time filter in Recent and All Friends
    allFriendsContainer.querySelectorAll('.friend-item').forEach(card => {
      const name = card.dataset.friendName || '';
      card.style.display = name.includes(term) ? 'block' : 'none';
    });
    
    if (recentSection) {
      const recentContainer = document.getElementById('recentFriendsModalContainer');
      recentContainer.querySelectorAll('.friend-item').forEach(card => {
        const name = card.dataset.friendName || '';
        if (name.includes(term)) {
          card.style.display = 'block';
        } else {
          card.style.display = 'none';
          // Hide entire recent section if no matches
          const visibleInRecent = Array.from(recentContainer.querySelectorAll('.friend-item')).some(c => c.style.display !== 'none');
          recentSection.style.display = visibleInRecent ? 'block' : 'none';
        }
      });
    }
  });
  
  // Hide dropdown when clicking outside
  document.addEventListener('click', (e) => {
    if (!searchInput.contains(e.target) && !dropdown.contains(e.target)) {
      dropdown.style.display = 'none';
    }
  });
}

function createFriendCard(friend) {
  const friendDiv = document.createElement('div');
  friendDiv.className = 'friend-item';
  friendDiv.style.marginBottom = '8px';
  friendDiv.dataset.friendName = friend.friend_name.toLowerCase();
  
  friendDiv.innerHTML = `
    <div class="friend-info">
      <div>
        <div class="friend-name">${friend.friend_name}</div>
        <div class="friend-email">${friend.friend_email}</div>
      </div>
    </div>
  `;
  
  const actionsDiv = document.createElement('div');
  actionsDiv.className = 'friend-actions';
  
  const viewListsBtn = document.createElement('button');
  viewListsBtn.className = 'btn-small';
  viewListsBtn.textContent = 'View Lists';
  viewListsBtn.addEventListener('click', async () => {
    await addToRecentFriends(friend.friend_id);
    hideModal();
    viewFriendLists(friend.friend_id, friend.friend_name);
  });
  actionsDiv.appendChild(viewListsBtn);
  
  friendDiv.querySelector('.friend-info').appendChild(actionsDiv);
  
  return friendDiv;
}

async function loadBrowseFriends() {
  const container = document.getElementById('browseFriendsContainer');
  container.innerHTML = '<div class="loading">Loading friends...</div>';
  
  try {
    const friends = await supabaseRPC('get_friends', {});
    
    if (friends.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">👥</div>
          <div>No friends yet</div>
          <div style="font-size: 12px; margin-top: 8px;">Add friends to share hintlists!</div>
        </div>
      `;
      return;
    }
    
    // Store all friends for filtering
    window.allFriends = friends;
    
    // Load recent friends
    await loadRecentFriends();
    
    // Display all friends
    displayFriendsList(friends, container);
  } catch (error) {
    container.innerHTML = '<div class="empty-state">Error loading friends</div>';
  }
}

async function loadRecentFriends() {
  const { recentFriends = [] } = await chrome.storage.local.get('recentFriends');
  
  if (recentFriends.length === 0) {
    document.getElementById('recentFriendsSection').classList.add('hidden');
    return;
  }
  
  document.getElementById('recentFriendsSection').classList.remove('hidden');
  const container = document.getElementById('recentFriendsContainer');
  container.innerHTML = '';
  
  // Get friend details for recent IDs
  const allFriends = window.allFriends || [];
  const recentFriendData = recentFriends
    .map(id => allFriends.find(f => f.friend_id === id))
    .filter(f => f !== undefined)
    .slice(0, 3); // Show max 3 recent
  
  recentFriendData.forEach(friend => {
    const friendDiv = createFriendCard(friend, true);
    container.appendChild(friendDiv);
  });
}

function createFriendCard(friend, isRecent = false) {
  const friendDiv = document.createElement('div');
  friendDiv.className = 'friend-item';
  friendDiv.style.marginBottom = '8px';
  
  friendDiv.innerHTML = `
    <div class="friend-info">
      <div>
        <div class="friend-name">${friend.friend_name}</div>
        <div class="friend-email">${friend.friend_email}</div>
      </div>
    </div>
  `;
  
  const actionsDiv = document.createElement('div');
  actionsDiv.className = 'friend-actions';
  
  const viewListsBtn = document.createElement('button');
  viewListsBtn.className = 'btn-small';
  viewListsBtn.textContent = 'View Lists';
  viewListsBtn.addEventListener('click', async () => {
    await addToRecentFriends(friend.friend_id);
    viewFriendLists(friend.friend_id, friend.friend_name);
  });
  actionsDiv.appendChild(viewListsBtn);
  
  friendDiv.querySelector('.friend-info').appendChild(actionsDiv);
  
  return friendDiv;
}

function displayFriendsList(friends, container) {
  container.innerHTML = '';
  
  friends.forEach(friend => {
    const friendDiv = createFriendCard(friend);
    friendDiv.dataset.friendName = friend.friend_name.toLowerCase();
    friendDiv.dataset.friendEmail = friend.friend_email.toLowerCase();
    container.appendChild(friendDiv);
  });
}

function filterFriends(searchTerm) {
  const container = document.getElementById('browseFriendsContainer');
  const friendCards = container.querySelectorAll('.friend-item');
  const term = searchTerm.toLowerCase().trim();
  
  if (!term) {
    // Show all
    friendCards.forEach(card => card.style.display = 'block');
    return;
  }
  
  // Filter by name or email
  friendCards.forEach(card => {
    const name = card.dataset.friendName || '';
    const email = card.dataset.friendEmail || '';
    
    if (name.includes(term) || email.includes(term)) {
      card.style.display = 'block';
    } else {
      card.style.display = 'none';
    }
  });
}

async function addToRecentFriends(friendId) {
  const { recentFriends = [] } = await chrome.storage.local.get('recentFriends');
  
  // Remove if already exists
  const filtered = recentFriends.filter(id => id !== friendId);
  
  // Add to beginning
  const updated = [friendId, ...filtered].slice(0, 5); // Keep max 5
  
  await chrome.storage.local.set({ recentFriends: updated });
}

async function loadMyClaims() {
  const container = document.getElementById('myClaimsContainer');
  container.innerHTML = '<div class="loading">Loading your claims...</div>';
  
  try {
    const claims = await supabaseRPC('get_my_claimed_products', {});
    
    if (claims.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">🎁</div>
          <div>No claimed items yet</div>
          <div style="font-size: 12px; margin-top: 8px;">Items you claim from friends' hintlists will appear here</div>
        </div>
      `;
      return;
    }
    
    container.innerHTML = '';
    
    // Group by list
    const groupedByList = {};
    claims.forEach(claim => {
      const key = claim.list_name;
      if (!groupedByList[key]) {
        groupedByList[key] = {
          listName: claim.list_name,
          ownerName: claim.list_owner_name,
          products: []
        };
      }
      groupedByList[key].products.push(claim);
    });
    
    // Display each list group
    Object.values(groupedByList).forEach(group => {
      const listDiv = document.createElement('div');
      listDiv.className = 'list-item';
      
      listDiv.innerHTML = `
        <div class="list-header">
          <div class="list-name">${group.listName}</div>
          <div class="list-badges">
            <span class="badge count">${group.products.length} claimed</span>
          </div>
        </div>
        <div style="font-size: 12px; color: #6c757d; margin-bottom: 8px;">
          From ${group.ownerName}'s hintlist
        </div>
      `;
      
      group.products.forEach(claim => {
        const productDiv = document.createElement('div');
        productDiv.className = 'product-item claimed';
        
        // Thumbnail
        const thumbnailDiv = document.createElement('div');
        thumbnailDiv.className = 'product-thumbnail';
        if (claim.image_url) {
          const img = document.createElement('img');
          img.src = claim.image_url;
          img.alt = claim.product_name;
          img.onerror = () => {
            thumbnailDiv.innerHTML = '<div class="product-thumbnail-placeholder">📦</div>';
          };
          thumbnailDiv.appendChild(img);
        } else {
          thumbnailDiv.innerHTML = '<div class="product-thumbnail-placeholder">📦</div>';
        }
        productDiv.appendChild(thumbnailDiv);
        
        // Product details container
        const detailsDiv = document.createElement('div');
        detailsDiv.className = 'product-details';
        
        const nameDiv = document.createElement('div');
        nameDiv.className = 'product-name';
        nameDiv.textContent = claim.product_name;
        detailsDiv.appendChild(nameDiv);
        
        if (claim.current_price) {
          const priceDiv = document.createElement('div');
          priceDiv.className = 'product-meta';
          priceDiv.textContent = `$${claim.current_price}`;
          detailsDiv.appendChild(priceDiv);
        }
        
        const claimedDiv = document.createElement('div');
        claimedDiv.className = 'product-meta';
        claimedDiv.style.color = '#28a745';
        claimedDiv.textContent = `✓ Claimed ${new Date(claim.claimed_at).toLocaleDateString()}`;
        detailsDiv.appendChild(claimedDiv);
        
        const actionsDiv = document.createElement('div');
        actionsDiv.className = 'product-actions';
        
        if (claim.product_url) {
          const visitBtn = document.createElement('button');
          visitBtn.className = 'btn-small';
          visitBtn.style.background = '#228855';
          visitBtn.style.color = 'white';
          visitBtn.textContent = '🛒 Buy Now';
          visitBtn.addEventListener('click', () => window.open(claim.product_url, '_blank'));
          actionsDiv.appendChild(visitBtn);
        }
        
        const unclaimBtn = document.createElement('button');
        unclaimBtn.className = 'btn-small secondary';
        unclaimBtn.textContent = 'Unclaim';
        unclaimBtn.addEventListener('click', async () => {
          if (!confirm(`Unclaim "${claim.product_name}"?`)) return;
          try {
            const result = await supabaseRPC('unclaim_product', { product_id: claim.product_id });
            if (result.success) {
              showMessage('addMessage', 'Item unclaimed', 'success');
              await loadMyClaims();
            } else {
              showMessage('addMessage', result.error || 'Error unclaiming', 'error');
            }
          } catch (error) {
            showMessage('addMessage', 'Error unclaiming item', 'error');
          }
        });
        actionsDiv.appendChild(unclaimBtn);
        
        detailsDiv.appendChild(actionsDiv);
        productDiv.appendChild(detailsDiv);
        listDiv.appendChild(productDiv);
      });
      
      container.appendChild(listDiv);
    });
  } catch (error) {
    container.innerHTML = '<div class="empty-state">Error loading claims</div>';
  }
}

// Helper function for RPC calls
async function supabaseRPC(functionName, params) {
  return await supabaseRequest('POST', `/rest/v1/rpc/${functionName}`, params);
}

function switchTab(tab) {
  document.querySelectorAll('.tab-buttons button').forEach(btn => btn.classList.remove('active'));
  
  document.getElementById('addView').classList.add('hidden');
  document.getElementById('myListsView').classList.add('hidden');
  document.getElementById('myClaimsView').classList.add('hidden');
  document.getElementById('viewHintlistView').classList.add('hidden');
  
  if (tab === 'add') {
    document.getElementById('addTab').classList.add('active');
    document.getElementById('addView').classList.remove('hidden');
    autoFillCurrentPage();
  } else if (tab === 'myLists') {
    document.getElementById('myListsTab').classList.add('active');
    document.getElementById('myListsView').classList.remove('hidden');
    displayMyLists();
  } else if (tab === 'myClaims') {
    document.getElementById('myClaimsTab').classList.add('active');
    document.getElementById('myClaimsView').classList.remove('hidden');
    loadMyClaims();
  } else if (tab === 'viewHintlist') {
    document.getElementById('viewHintlistTab').classList.add('active');
    document.getElementById('viewHintlistView').classList.remove('hidden');
  }
}

function showConfig() {
  hideAllSections();
  document.getElementById('configSection').classList.remove('hidden');
  const browseFriendsBtn = document.getElementById('browseFriendsBtn');
  const friendsSettingsBtn = document.getElementById('friendsSettingsBtn');
  if (browseFriendsBtn) {
    browseFriendsBtn.classList.add('hidden');
  }
  if (friendsSettingsBtn) {
    friendsSettingsBtn.classList.add('hidden');
  }
}

function showLogin() {
  hideAllSections();
  document.getElementById('loginSection').classList.remove('hidden');
  const browseFriendsBtn = document.getElementById('browseFriendsBtn');
  const friendsSettingsBtn = document.getElementById('friendsSettingsBtn');
  if (browseFriendsBtn) {
    browseFriendsBtn.classList.add('hidden');
  }
  if (friendsSettingsBtn) {
    friendsSettingsBtn.classList.add('hidden');
  }
}

function showSignup() {
  hideAllSections();
  document.getElementById('signupSection').classList.remove('hidden');
  const browseFriendsBtn = document.getElementById('browseFriendsBtn');
  const friendsSettingsBtn = document.getElementById('friendsSettingsBtn');
  if (browseFriendsBtn) {
    browseFriendsBtn.classList.add('hidden');
  }
  if (friendsSettingsBtn) {
    friendsSettingsBtn.classList.add('hidden');
  }
}

function showApp() {
  hideAllSections();
  document.getElementById('appSection').classList.remove('hidden');
  const browseFriendsBtn = document.getElementById('browseFriendsBtn');
  const friendsSettingsBtn = document.getElementById('friendsSettingsBtn');
  if (browseFriendsBtn) {
    browseFriendsBtn.classList.remove('hidden');
  }
  if (friendsSettingsBtn) {
    friendsSettingsBtn.classList.remove('hidden');
  }
  
  // Get user's name and email
  const fullName = currentUser?.user_metadata?.name || 
                   currentUser?.name || 
                   currentUser?.email?.split('@')[0] || 
                   'user';
  
  // Extract first name - split by space OR dot (preserve original capitalization)
  const userName = fullName.split(/[\s.]+/)[0];
  const userEmail = currentUser?.email || currentUser?.user?.email || '';
  
  // Display as: name • email
  document.getElementById('userInfo').textContent = `${userName} • ${userEmail}`;
}

function hideAllSections() {
  document.getElementById('configSection').classList.add('hidden');
  document.getElementById('loginSection').classList.add('hidden');
  document.getElementById('signupSection').classList.add('hidden');
  document.getElementById('appSection').classList.add('hidden');
}

function showMessage(elementId, text, type) {
  const el = document.getElementById(elementId);
  if (el) {
    el.className = `message ${type}`;
    el.textContent = text;
    setTimeout(() => el.textContent = '', 4000);
  }
}

function showCustomModal(title, bodyHtml, onConfirm) {
  const modal = document.getElementById('modalContent');
  modal.innerHTML = `
    <div class="modal-header">${title}</div>
    <div class="modal-body">${bodyHtml}</div>
    <div class="modal-buttons">
      <button id="modalCancelBtn" class="secondary">Cancel</button>
      <button id="modalConfirmBtn">Confirm</button>
    </div>
  `;
  
  document.getElementById('modalOverlay').classList.add('show');
  
  document.getElementById('modalCancelBtn').addEventListener('click', hideModal);
  document.getElementById('modalConfirmBtn').addEventListener('click', onConfirm);
  
  // Auto-focus first input
  setTimeout(() => {
    const firstInput = modal.querySelector('input');
    if (firstInput) firstInput.focus();
  }, 100);
}

function hideModal() {
  document.getElementById('modalOverlay').classList.remove('show');
}

// Export list to Excel (CSV format)
function exportListToExcel(list, products) {
  // Create CSV content
  const headers = ['Product Name', 'URL', 'Claimed', 'Date Added', 'Current Price'];
  const rows = [headers];
  
  products.forEach(product => {
    const row = [
      product.name || '',
      product.url || '',
      product.claimed_by ? 'Yes' : 'No',
      product.created_at ? new Date(product.created_at).toLocaleDateString() : '',
      product.current_price ? `$${product.current_price}` : 'N/A'
    ];
    rows.push(row);
  });
  
  // Convert to CSV string
  const csvContent = rows.map(row => 
    row.map(cell => {
      // Escape quotes and wrap in quotes if contains comma
      const escaped = String(cell).replace(/"/g, '""');
      return escaped.includes(',') || escaped.includes('\n') ? `"${escaped}"` : escaped;
    }).join(',')
  ).join('\n');
  
  // Create blob and download
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${list.name.replace(/[^a-z0-9]/gi, '_')}_${new Date().toISOString().split('T')[0]}.csv`;
  link.click();
  URL.revokeObjectURL(url);
  
  showMessage('addMessage', 'List exported successfully!', 'success');
}