// Content script - runs on all pages
// Can be used to extract product information automatically

// Future enhancement: Detect product pages and extract price/title automatically
function detectProductInfo() {
  // Common selectors for product prices across retailers
  const priceSelectors = [
    '[itemprop="price"]',
    '.price',
    '[data-price]',
    '#priceblock_ourprice', // Amazon
    '.product-price',
    '[class*="price"]'
  ];
  
  let price = null;
  for (const selector of priceSelectors) {
    const element = document.querySelector(selector);
    if (element) {
      price = element.textContent.trim();
      break;
    }
  }
  
  return {
    title: document.title,
    url: window.location.href,
    price
  };
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getProductInfo') {
    sendResponse(detectProductInfo());
  }
});

// Future: Could add floating button to add products directly from page
// For now, users will use the extension popup