// hint Extension - Minimal Background Worker
console.log('hint background worker started');